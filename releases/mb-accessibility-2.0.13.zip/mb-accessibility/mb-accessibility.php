<?php
/**
 * Plugin Name: MB Accessibility
 * Plugin URI:  https://mbdigitalinnovation.ch
 * Description: Widget di accessibilità per WordPress con screen reader integrato, modalità di contrasto, regolazione testo, pausa animazioni e molto altro. Sviluppato da MB Digital Innovation.
 * Version:     2.0.13
 * Author:      MB Digital Innovation
 * Author URI:  https://mbdigitalinnovation.ch
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: mb-accessibility
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------------
// Plugin constants
// ---------------------------------------------------------------------------
define( 'MBA_VERSION',  '2.0.13' );
define( 'MBA_FILE',     __FILE__ );
define( 'MBA_PATH',     plugin_dir_path( __FILE__ ) );
define( 'MBA_URL',      plugin_dir_url( __FILE__ ) );

// ---------------------------------------------------------------------------
// Auto-updater (Plugin Update Checker – reads manifest from public repo)
// ---------------------------------------------------------------------------
require_once MBA_PATH . 'includes/lib/plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$mba_updater = PucFactory::buildUpdateChecker(
	'https://raw.githubusercontent.com/Federicob88/mb-accessibility-updates/main/update.json',
	__FILE__,
	'mb-accessibility'
);

// ---------------------------------------------------------------------------
// Autoload classes
// ---------------------------------------------------------------------------
require_once MBA_PATH . 'includes/class-plugin.php';
require_once MBA_PATH . 'includes/class-admin.php';
require_once MBA_PATH . 'includes/class-frontend.php';

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------
add_action( 'plugins_loaded', array( 'MBA_Plugin', 'get_instance' ) );
