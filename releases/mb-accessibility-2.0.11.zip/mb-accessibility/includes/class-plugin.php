<?php
/**
 * MB Accessibility – Main plugin class (singleton).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MBA_Plugin {

	/** @var MBA_Plugin|null */
	private static $instance = null;

	// -----------------------------------------------------------------------
	// LICENSE – HMAC salt (change this string before distributing)
	// Never share or publish this value.
	// -----------------------------------------------------------------------

	/**
	 * Secret salt used to verify license keys.
	 * Each key is: HMAC-SHA256( bare_domain, MBA_LICENSE_SALT )
	 * truncated to 32 hex chars and formatted as XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX.
	 */
	private const LICENSE_SALT = 'MB$Dig!talInn0vat10n_2025#SecretSalt_ch';

	// -----------------------------------------------------------------------
	// Singleton
	// -----------------------------------------------------------------------

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'load_textdomain' ) );

		if ( is_admin() ) {
			new MBA_Admin();
		}

		// Only load the frontend widget if the license is valid
		if ( self::is_licensed() ) {
			new MBA_Frontend();
		}
	}

	// -----------------------------------------------------------------------
	// Text domain
	// -----------------------------------------------------------------------

	public function load_textdomain(): void {
		load_plugin_textdomain(
			'mb-accessibility',
			false,
			dirname( plugin_basename( MBA_FILE ) ) . '/languages'
		);
	}

	// -----------------------------------------------------------------------
	// License helpers
	// -----------------------------------------------------------------------

	/**
	 * Returns the bare domain of the current WordPress installation
	 * (strips www. prefix and port, lowercased).
	 */
	public static function get_domain(): string {
		$host = parse_url( home_url(), PHP_URL_HOST ) ?: '';
		$host = strtolower( $host );
		$host = preg_replace( '/^www\./', '', $host );
		$host = preg_replace( '/:\d+$/', '', $host );  // strip :port
		return $host;
	}

	/**
	 * Generates the expected license key for a given domain.
	 * The key is the first 32 hex chars of HMAC-SHA256, grouped in 8×4.
	 *
	 * @param string $domain  Bare domain (e.g. "example.com")
	 * @return string  Formatted key, e.g. "A3F2-9C1D-..."
	 */
	public static function generate_key( string $domain ): string {
		$domain = strtolower( trim( $domain ) );
		$hash   = strtoupper( substr( hash_hmac( 'sha256', $domain, self::LICENSE_SALT ), 0, 32 ) );
		return implode( '-', str_split( $hash, 4 ) );
	}

	/**
	 * Normalises a key string entered by the user (removes dashes, spaces, lowercases).
	 */
	private static function normalise_key( string $key ): string {
		return strtoupper( preg_replace( '/[\s\-]/', '', $key ) );
	}

	/**
	 * Returns true if the saved license key is valid for the current domain.
	 */
	public static function is_licensed(): bool {
		$s   = self::get_settings();
		$key = $s['license_key'] ?? '';
		if ( empty( $key ) ) {
			return false;
		}
		$expected = self::normalise_key( self::generate_key( self::get_domain() ) );
		$provided = self::normalise_key( $key );
		return hash_equals( $expected, $provided );
	}

	// -----------------------------------------------------------------------
	// Settings helpers
	// -----------------------------------------------------------------------

	/**
	 * Returns the default settings array.
	 */
	public static function get_default_settings(): array {
		return array(
			// License
			'license_key'                 => '',
			// Widget appearance
			'position'                    => 'right',
			'position_mobile'             => 'right',
			'color'                       => '#1a6baa',
			'show_on_mobile'              => '1',
			'toggle_icon_url'             => '',
			// Navigation
			'skip_to_content'             => '1',
			'skip_to_content_target'      => 'content',
			'accessibility_statement_url' => '',
			// Screen reader
			'screen_reader_enabled'       => '1',
			'screen_reader_mode'          => 'click',  // 'click' | 'hover'
			// Features v1
			'features_font_size'          => '1',
			'features_high_contrast'      => '1',
			'features_grayscale'          => '1',
			'features_invert'             => '1',
			'features_readable_font'      => '1',
			'features_underline_links'    => '1',
			'features_pause_animations'   => '1',
			'features_hide_images'        => '1',
			'features_line_height'        => '1',
			// Features v2.0
			'features_colorblind'         => '1',
			'features_letter_spacing'     => '1',
			'features_text_left'          => '1',
			'features_focus_indicator'    => '1',
			'features_reading_guide'      => '1',
			'features_big_cursor'         => '1',
			// Reading guide
			'reading_guide_height'        => '22',
		);
	}

	/**
	 * Returns merged saved + default settings.
	 */
	public static function get_settings(): array {
		$saved = get_option( 'mba_settings', array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::get_default_settings() );
	}

	// -----------------------------------------------------------------------
	// Activation hook
	// -----------------------------------------------------------------------

	public static function activate(): void {
		if ( ! get_option( 'mba_settings' ) ) {
			update_option( 'mba_settings', self::get_default_settings() );
		}
	}
}

register_activation_hook( MBA_FILE, array( 'MBA_Plugin', 'activate' ) );
