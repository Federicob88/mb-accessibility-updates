/**
 * MB Accessibility – Widget JavaScript v2.0.0
 * Handles panel open/close, feature toggling, localStorage persistence,
 * and the integrated TTS Screen Reader (Web Speech API).
 *
 * No dependencies. Vanilla JS only.
 */

( function () {
	'use strict';

	/* ========================================================================
	   CONFIG injected by wp_localize_script as `mbaConfig`
	   ======================================================================== */
	const CFG      = window.mbaConfig || {};
	const i18n     = CFG.i18n     || {};
	const features = CFG.features || {};

	/* ========================================================================
	   FONT SIZE LEVELS  (index 0 = default / 100%)
	   ======================================================================== */
	const FONT_LEVELS = [ 0, 110, 125, 140, 160, 185 ];

	/* ========================================================================
	   LETTER SPACING LEVELS  (extra px, index 0 = no change)
	   ======================================================================== */
	const LETTER_LEVELS = [ 0, 1, 2, 4 ];

	/* ========================================================================
	   STATE  (serialised to localStorage)
	   ======================================================================== */
	const DEFAULT_STATE = {
		active:       {},   // { featureKey: true|false }
		fontLevel:    0,    // 0-5
		spacingLevel: 0,    // 0-3
		srActive:     false,
		srSpeed:      1,
		expires:      0,
	};

	let state = Object.assign( {}, DEFAULT_STATE );

	/* ========================================================================
	   CONSTANTS
	   ======================================================================== */
	const LS_KEY = 'mba-prefs';
	const BODY   = document.body;

	/* ========================================================================
	   DOM REFERENCES  (populated in init)
	   ======================================================================== */
	let el = {};

	/* ========================================================================
	   DEVICE HELPERS
	   ======================================================================== */

	/** True when the primary input is touch (smartphone/tablet). */
	function isTouchDevice() {
		return window.matchMedia( '(hover: none) and (pointer: coarse)' ).matches;
	}

	/** True when viewport width is ≤ 480 px (matches CSS mobile breakpoint). */
	function isMobileViewport() {
		return window.matchMedia( '(max-width: 480px)' ).matches;
	}

	/**
	 * Apply the correct mba-pos-* class on the widget wrapper based on the
	 * current viewport width and the desktop/mobile position settings.
	 */
	function applyPositionClass() {
		const wrapper = document.getElementById( 'mba-widget-wrapper' );
		if ( ! wrapper ) return;
		const pos = isMobileViewport()
			? ( CFG.positionMobile || CFG.position || 'right' )
			: ( CFG.position || 'right' );
		wrapper.classList.remove( 'mba-pos-left', 'mba-pos-right' );
		wrapper.classList.add( 'mba-pos-' + pos );
	}

	/* ========================================================================
	   COLOR BLINDNESS – SVG feColorMatrix filters
	   ======================================================================== */

	/**
	 * Maps colorblind profile keys → CSS filter() references.
	 * The SVG filters are injected once into the DOM by injectSVGFilters().
	 */
	const COLORBLIND_FILTERS = {
		deuteranopia: 'url(#mba-deuteranopia)',
		protanopia:   'url(#mba-protanopia)',
		tritanopia:   'url(#mba-tritanopia)',
	};

	/**
	 * Inject an invisible SVG <defs> block with the three feColorMatrix
	 * filters needed for colour-blindness simulation.
	 * Called once in init(); safe to call multiple times.
	 */
	function injectSVGFilters() {
		if ( document.getElementById( 'mba-svg-filters' ) ) return;

		const ns  = 'http://www.w3.org/2000/svg';
		const svg = document.createElementNS( ns, 'svg' );
		svg.id = 'mba-svg-filters';
		svg.setAttribute( 'xmlns', ns );
		svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none;';
		svg.setAttribute( 'aria-hidden', 'true' );

		const defs = document.createElementNS( ns, 'defs' );

		// feColorMatrix values: 4 rows × 5 columns (R G B A offset)
		const matrices = {
			'mba-deuteranopia': '0.625 0.375 0 0 0  0.700 0.300 0 0 0  0 0.300 0.700 0 0  0 0 0 1 0',
			'mba-protanopia':   '0.567 0.433 0 0 0  0.558 0.442 0 0 0  0 0.242 0.758 0 0  0 0 0 1 0',
			'mba-tritanopia':   '0.950 0.050 0 0 0  0 0.433 0.567 0 0  0 0.475 0.525 0 0  0 0 0 1 0',
		};

		Object.entries( matrices ).forEach( ( [ id, values ] ) => {
			const filter = document.createElementNS( ns, 'filter' );
			filter.id = id;
			filter.setAttribute( 'color-interpolation-filters', 'sRGB' );

			const fe = document.createElementNS( ns, 'feColorMatrix' );
			fe.setAttribute( 'type',   'matrix' );
			fe.setAttribute( 'values', values );
			filter.appendChild( fe );
			defs.appendChild( filter );
		} );

		svg.appendChild( defs );

		// Insert at start of body so it is in the document before filters are used
		BODY.insertAdjacentElement( 'afterbegin', svg );
	}

	/**
	 * Apply body.style.filter for the currently-active colorblind profile
	 * (or clear it if none is active).
	 */
	function applyBodyFilter() {
		const active = Object.keys( COLORBLIND_FILTERS ).find( k => state.active[ k ] );
		const val    = active ? COLORBLIND_FILTERS[ active ] : '';
		BODY.style.filter         = val;
		BODY.style.webkitFilter   = val;
	}

	/* ========================================================================
	   SCREEN READER
	   ======================================================================== */
	const SR = {
		supported:         'speechSynthesis' in window,
		reading:           false,
		hoverTimer:        null,
		boundClickHandler: null,
		boundHoverIn:      null,
		boundHoverOut:     null,

		speak( text ) {
			if ( ! this.supported || ! text || ! text.trim() ) return;
			window.speechSynthesis.cancel();
			const utt  = new SpeechSynthesisUtterance( text.trim() );
			utt.lang   = document.documentElement.lang || 'en';
			utt.rate   = state.srSpeed || 1;

			const voices = window.speechSynthesis.getVoices();
			const lang   = utt.lang.split( '-' )[ 0 ];
			const match  = voices.find( v => v.lang.startsWith( lang ) );
			if ( match ) utt.voice = match;

			this.reading = true;
			this.updateUI();

			utt.onend = utt.onerror = () => {
				this.reading = false;
				this.updateUI();
			};

			window.speechSynthesis.speak( utt );
		},

		stop() {
			window.speechSynthesis.cancel();
			this.reading = false;
			this.updateUI();
		},

		updateUI() {
			if ( ! el.srStatus ) return;
			if ( this.reading ) {
				el.srStatus.textContent = i18n.srReading || 'Reading…';
				if ( el.srStop ) el.srStop.style.display = 'flex';
			} else {
				const mode = CFG.srMode === 'hover'
					? ( i18n.srHoverPrompt || '' )
					: ( i18n.srClickPrompt || '' );
				el.srStatus.textContent = state.srActive ? mode : '';
				if ( el.srStop ) el.srStop.style.display = 'none';
			}
		},

		textFrom( target ) {
			return (
				target.getAttribute( 'aria-label' ) ||
				target.getAttribute( 'alt' )         ||
				target.innerText                      ||
				target.textContent                    ||
				''
			).replace( /\s+/g, ' ' ).trim();
		},

		bestText( target ) {
			let node = target, text = '';
			for ( let i = 0; i < 4 && node; i++ ) {
				text = this.textFrom( node );
				if ( text.length > 3 ) break;
				node = node.parentElement;
			}
			return text;
		},

		activate() {
			if ( ! this.supported ) {
				if ( el.srStatus ) el.srStatus.textContent = i18n.srNotSupported || '';
				return;
			}
			window.speechSynthesis.getVoices();
			BODY.classList.add( 'mba-sr-active' );

			if ( CFG.srMode === 'hover' ) {
				this.boundHoverIn  = ( e ) => {
					clearTimeout( this.hoverTimer );
					this.hoverTimer = setTimeout( () => {
						if ( e.target.closest( '#mba-widget-wrapper' ) ) return;
						this.speak( this.bestText( e.target ) );
					}, 350 );
				};
				this.boundHoverOut = () => clearTimeout( this.hoverTimer );
				document.addEventListener( 'mouseover', this.boundHoverIn );
				document.addEventListener( 'mouseout',  this.boundHoverOut );
			} else {
				this.boundClickHandler = ( e ) => {
					if ( e.target.closest( '#mba-widget-wrapper' ) ) return;
					e.preventDefault();
					this.speak( this.bestText( e.target ) );
				};
				document.addEventListener( 'click', this.boundClickHandler, true );
			}

			if ( el.srSpeedWrap ) el.srSpeedWrap.style.display = 'flex';
			this.updateUI();
		},

		deactivate() {
			BODY.classList.remove( 'mba-sr-active' );
			this.stop();

			if ( this.boundClickHandler ) {
				document.removeEventListener( 'click', this.boundClickHandler, true );
				this.boundClickHandler = null;
			}
			if ( this.boundHoverIn ) {
				document.removeEventListener( 'mouseover', this.boundHoverIn );
				document.removeEventListener( 'mouseout',  this.boundHoverOut );
				this.boundHoverIn  = null;
				this.boundHoverOut = null;
			}
			clearTimeout( this.hoverTimer );

			if ( el.srSpeedWrap ) el.srSpeedWrap.style.display = 'none';
			if ( el.srStatus    ) el.srStatus.textContent = '';
		},
	};

	/* ========================================================================
	   FEATURE CLASS MAP  (feature key → CSS body class)
	   ======================================================================== */

	const FEATURE_CLASS = {
		// v1
		highContrast:    'mba-high-contrast',
		grayscale:       'mba-grayscale',
		invert:          'mba-invert',
		readableFont:    'mba-readable-font',
		underlineLinks:  'mba-underline-links',
		pauseAnimations: 'mba-pause-animations',
		hideImages:      'mba-hide-images',
		lineHeight:      'mba-line-height',
		// v2.0 – simple class toggles
		textLeft:        'mba-text-left',
		focusIndicator:  'mba-focus-indicator',
		bigCursor:       'mba-big-cursor',
	};

	/**
	 * All visual colour-manipulation features are mutually exclusive.
	 * Includes both CSS-class-based (highContrast, grayscale, invert)
	 * and filter-based (colorblind profiles).
	 */
	const VISUAL_EXCLUSIVE = [
		'highContrast', 'grayscale', 'invert',
		'deuteranopia', 'protanopia', 'tritanopia',
	];

	function applyFeature( key, on ) {
		const cls = FEATURE_CLASS[ key ];
		if ( ! cls ) return;
		BODY.classList.toggle( cls, !! on );
	}

	/* ========================================================================
	   FONT SIZE
	   ======================================================================== */

	/**
	 * CSS selector targeting all text-bearing elements we scale.
	 * Kept as a constant so capture and cleanup use the same list.
	 */
	const FONT_SEL = [
		'body p', 'body li', 'body dt', 'body dd',
		'body h1', 'body h2', 'body h3', 'body h4', 'body h5', 'body h6',
		'body td', 'body th', 'body caption', 'body blockquote',
		'body label', 'body figcaption', 'body summary',
		'body input:not([type="hidden"])', 'body select', 'body textarea',
		'body .entry-content', 'body .post-content', 'body article',
	].join( ', ' );

	/**
	 * Map<Element, number> – each element's computed font-size (px) captured
	 * BEFORE any override is applied.  Null = not yet captured this session.
	 * Reset to null on full reset (level 0) so the next activation re-reads
	 * the true theme sizes from a clean DOM.
	 */
	let fontBaselines = null;

	function applyFontLevel( level ) {
		// 1. Remove html font-size override so the DOM returns to theme state.
		document.documentElement.style.fontSize = '';

		// 2. Remove per-element inline overrides from the previous level.
		if ( fontBaselines ) {
			fontBaselines.forEach( function ( _, node ) {
				if ( node.isConnected ) {
					node.style.removeProperty( 'font-size' );
				}
			} );
		}

		// 3. Remove the legacy injected style tag (safety net for old sessions).
		const prev = document.getElementById( 'mba-font-override' );
		if ( prev ) prev.remove();

		if ( level === 0 ) {
			// Full reset: discard baselines so the next activation re-captures
			// fresh sizes from the clean DOM.
			fontBaselines = null;
			if ( el.fontCurrent ) el.fontCurrent.textContent = '100%';
			updateFontButtons();
			return;
		}

		// 4. Capture baselines exactly once, while the DOM is at true theme sizes
		//    (html font-size and inline overrides have both been cleared above).
		if ( ! fontBaselines ) {
			fontBaselines = new Map();
			document.querySelectorAll( FONT_SEL ).forEach( function ( node ) {
				fontBaselines.set(
					node,
					parseFloat( window.getComputedStyle( node ).fontSize )
				);
			} );
		}

		const scale = FONT_LEVELS[ level ] / 100;

		// 5. Scale html font-size: correctly handles rem-based themes and any
		//    new / dynamically-added elements that appear after baseline capture.
		document.documentElement.style.fontSize = FONT_LEVELS[ level ] + '%';

		// 6. Apply baseline × scale as an inline !important style on every
		//    captured element.  This fixes px-based themes where calc(1em * scale)
		//    would incorrectly use the parent's inherited size as the 1em base,
		//    causing elements with px values larger than 1em to shrink on first click.
		fontBaselines.forEach( function ( baseSize, node ) {
			if ( node.isConnected ) {
				node.style.setProperty(
					'font-size',
					( Math.round( baseSize * scale * 10 ) / 10 ) + 'px',
					'important'
				);
			}
		} );

		if ( el.fontCurrent ) {
			el.fontCurrent.textContent = FONT_LEVELS[ level ] + '%';
		}
		updateFontButtons();
	}

	function updateFontButtons() {
		if ( el.fontDec ) el.fontDec.disabled = state.fontLevel <= 0;
		if ( el.fontInc ) el.fontInc.disabled = state.fontLevel >= FONT_LEVELS.length - 1;
	}

	/* ========================================================================
	   LETTER SPACING  (v2.0)
	   ======================================================================== */

	function applyLetterSpacing( level ) {
		const prev = document.getElementById( 'mba-spacing-override' );
		if ( prev ) prev.remove();

		if ( level > 0 ) {
			const px     = LETTER_LEVELS[ level ];
			const wordPx = Math.round( px * 3.5 );
			const sel    = [
				'body p', 'body li', 'body dt', 'body dd',
				'body h1', 'body h2', 'body h3', 'body h4', 'body h5', 'body h6',
				'body td', 'body th', 'body caption', 'body blockquote',
				'body label', 'body figcaption', 'body summary',
				'body span', 'body a', 'body button',
			].join( ', ' );

			const style = document.createElement( 'style' );
			style.id    = 'mba-spacing-override';
			style.textContent =
				sel + ' { letter-spacing: ' + px + 'px !important; word-spacing: ' + wordPx + 'px !important; }';
			document.head.appendChild( style );
		}

		if ( el.spacingCurrent ) {
			el.spacingCurrent.textContent = level === 0 ? 'Std' : '+' + LETTER_LEVELS[ level ] + 'px';
		}
		updateSpacingButtons();
	}

	function updateSpacingButtons() {
		if ( el.spacingDec ) el.spacingDec.disabled = state.spacingLevel <= 0;
		if ( el.spacingInc ) el.spacingInc.disabled = state.spacingLevel >= LETTER_LEVELS.length - 1;
	}

	/* ========================================================================
	   READING GUIDE  (v2.0)
	   ======================================================================== */

	let readingGuideEl        = null;
	let readingGuideMoveHandler = null;

	function createReadingGuide() {
		if ( readingGuideEl ) return;

		const h      = Math.max( 4, parseInt( CFG.readingGuideHeight, 10 ) || 22 );
		const half   = Math.round( h / 2 );

		const guide = document.createElement( 'div' );
		guide.id = 'mba-reading-guide';
		guide.style.cssText = [
			'position:fixed',
			'left:0',
			'right:0',
			'height:' + h + 'px',
			'background:rgba(255,255,0,0.22)',
			'border-top:2px solid rgba(200,160,0,0.50)',
			'border-bottom:2px solid rgba(200,160,0,0.50)',
			'pointer-events:none',
			'z-index:2147483640',
			'top:-50px',
		].join( ';' );

		// Append to <html> so it's unaffected by body filters
		document.documentElement.appendChild( guide );
		readingGuideEl = guide;

		readingGuideMoveHandler = ( e ) => {
			const y = e.touches ? e.touches[ 0 ].clientY : e.clientY;
			guide.style.top = ( y - half ) + 'px';
		};

		document.addEventListener( 'mousemove', readingGuideMoveHandler );
		document.addEventListener( 'touchmove', readingGuideMoveHandler, { passive: true } );
	}

	function destroyReadingGuide() {
		if ( readingGuideEl ) {
			readingGuideEl.remove();
			readingGuideEl = null;
		}
		if ( readingGuideMoveHandler ) {
			document.removeEventListener( 'mousemove', readingGuideMoveHandler );
			document.removeEventListener( 'touchmove', readingGuideMoveHandler );
			readingGuideMoveHandler = null;
		}
	}

	/* ========================================================================
	   APPLY ALL STATE  (called on load to restore saved preferences)
	   ======================================================================== */

	function applyAllState() {
		// CSS class features
		Object.keys( FEATURE_CLASS ).forEach( key => {
			applyFeature( key, !! state.active[ key ] );
			updateBtn( key, !! state.active[ key ] );
		} );

		// Colorblind filter (body.style.filter)
		applyBodyFilter();
		Object.keys( COLORBLIND_FILTERS ).forEach( key => {
			updateBtn( key, !! state.active[ key ] );
		} );

		// Font size
		applyFontLevel( state.fontLevel );

		// Letter spacing
		applyLetterSpacing( state.spacingLevel || 0 );

		// Reading guide (skip on touch devices – no mouse cursor)
		if ( state.active.readingGuide && ! isTouchDevice() ) {
			createReadingGuide();
		} else if ( isTouchDevice() ) {
			// Clean state if somehow saved from a desktop session
			state.active.readingGuide = false;
		}
		updateBtn( 'readingGuide', !! state.active.readingGuide );

		// Screen reader
		if ( state.srActive && features.screenReader ) {
			SR.activate();
			updateBtn( 'screenReader', true );
		} else {
			SR.deactivate();
			updateBtn( 'screenReader', false );
		}
	}

	/* ========================================================================
	   BUTTON STATE
	   ======================================================================== */

	function updateBtn( key, active ) {
		const btn = el.featureBtns[ key ];
		if ( ! btn ) return;
		btn.setAttribute( 'aria-pressed', active ? 'true' : 'false' );
		btn.classList.toggle( 'is-active', active );
	}

	/* ========================================================================
	   TOGGLE FEATURE
	   ======================================================================== */

	function toggleFeature( key ) {

		// --- Screen Reader -----------------------------------------------
		if ( key === 'screenReader' ) {
			state.srActive = ! state.srActive;
			if ( state.srActive ) {
				SR.activate();
			} else {
				SR.deactivate();
			}
			updateBtn( 'screenReader', state.srActive );
			saveState();
			return;
		}

		// --- Reading Guide (desktop only) --------------------------------
		if ( key === 'readingGuide' ) {
			if ( isTouchDevice() ) return; // button hidden on touch, but guard anyway
			state.active.readingGuide = ! state.active.readingGuide;
			if ( state.active.readingGuide ) {
				createReadingGuide();
			} else {
				destroyReadingGuide();
			}
			updateBtn( 'readingGuide', state.active.readingGuide );
			saveState();
			return;
		}

		// --- Visual exclusive group (colour/filter modes) ----------------
		if ( VISUAL_EXCLUSIVE.includes( key ) ) {
			const wasActive = !! state.active[ key ];

			// Deactivate every member of the group
			VISUAL_EXCLUSIVE.forEach( k => {
				state.active[ k ] = false;
				if ( FEATURE_CLASS[ k ] ) applyFeature( k, false );
				updateBtn( k, false );
			} );
			// Clear any colorblind filter
			BODY.style.filter       = '';
			BODY.style.webkitFilter = '';

			if ( ! wasActive ) {
				state.active[ key ] = true;
				if ( COLORBLIND_FILTERS[ key ] ) {
					// Filter-based (colorblind profiles)
					BODY.style.filter       = COLORBLIND_FILTERS[ key ];
					BODY.style.webkitFilter = COLORBLIND_FILTERS[ key ];
				} else {
					// CSS class-based (highContrast, grayscale, invert)
					applyFeature( key, true );
				}
				updateBtn( key, true );
			}

			saveState();
			return;
		}

		// --- All other feature toggles -----------------------------------
		state.active[ key ] = ! state.active[ key ];
		applyFeature( key, state.active[ key ] );
		updateBtn( key, state.active[ key ] );
		saveState();
	}

	/* ========================================================================
	   RESET
	   ======================================================================== */

	function reset() {
		state.active       = {};
		state.fontLevel    = 0;
		state.spacingLevel = 0;
		state.srActive     = false;

		// Remove all CSS feature classes
		Object.values( FEATURE_CLASS ).forEach( cls => BODY.classList.remove( cls ) );

		// Clear body filter (colorblind / grayscale / invert if CSS-based)
		BODY.style.filter       = '';
		BODY.style.webkitFilter = '';

		// Screen reader
		SR.deactivate();

		// Font size  (also removes injected <style>)
		applyFontLevel( 0 );

		// Letter spacing
		applyLetterSpacing( 0 );

		// Reading guide
		destroyReadingGuide();

		// Reset all button states
		Object.keys( el.featureBtns ).forEach( k => updateBtn( k, false ) );

		clearStorage();
	}

	/* ========================================================================
	   PERSISTENCE  (localStorage)
	   ======================================================================== */

	function saveState() {
		try {
			const expMs = ( CFG.expiration || 24 ) * 3600 * 1000;
			state.expires = Date.now() + expMs;
			localStorage.setItem( LS_KEY, JSON.stringify( state ) );
		} catch ( e ) { /* storage disabled */ }
	}

	function loadState() {
		try {
			const raw = localStorage.getItem( LS_KEY );
			if ( ! raw ) return;
			const saved = JSON.parse( raw );
			if ( saved.expires && Date.now() > saved.expires ) {
				localStorage.removeItem( LS_KEY );
				return;
			}
			state = Object.assign( {}, DEFAULT_STATE, saved );
		} catch ( e ) { /* corrupted */ }
	}

	function clearStorage() {
		try { localStorage.removeItem( LS_KEY ); } catch ( e ) { /**/ }
	}

	/* ========================================================================
	   PANEL OPEN / CLOSE
	   ======================================================================== */

	function openPanel() {
		const panel  = el.panel;
		const toggle = el.toggle;
		if ( ! panel ) return;
		panel.classList.add( 'is-open' );
		panel.setAttribute( 'aria-hidden', 'false' );
		toggle.setAttribute( 'aria-expanded', 'true' );
		const focusable = panel.querySelectorAll(
			'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
		);
		if ( focusable.length ) focusable[ 0 ].focus();
	}

	function closePanel() {
		const panel  = el.panel;
		const toggle = el.toggle;
		if ( ! panel ) return;
		panel.classList.remove( 'is-open' );
		panel.setAttribute( 'aria-hidden', 'true' );
		toggle.setAttribute( 'aria-expanded', 'false' );
		toggle.focus();
	}

	/* ========================================================================
	   LABELS  (i18n)
	   ======================================================================== */

	function setLabels() {
		const setTxt = ( id, key ) => {
			const node = document.getElementById( id );
			if ( node ) node.textContent = i18n[ key ] || '';
		};

		// Panel-level
		setTxt( 'mba-panel-title',       'panelTitle'     );
		setTxt( 'mba-reset-label',       'reset'          );
		setTxt( 'mba-statement-text',    'statement'      );

		// Section headings
		setTxt( 'mba-sec-visual-label',  'sectionVisual'  );
		setTxt( 'mba-sec-text-label',    'sectionText'    );
		setTxt( 'mba-sec-nav-label',     'sectionNav'     );
		setTxt( 'mba-sec-sr-label',      'sectionSR'      );

		// Visual feature buttons
		setTxt( 'mba-lbl-highContrast',   'highContrast'   );
		setTxt( 'mba-lbl-grayscale',      'grayscale'      );
		setTxt( 'mba-lbl-invert',         'invert'         );
		setTxt( 'mba-lbl-pauseAnimations','pauseAnimations' );
		setTxt( 'mba-lbl-hideImages',     'hideImages'     );

		// Colorblind sub-section
		setTxt( 'mba-lbl-colorblindHint', 'colorblindHint' );
		setTxt( 'mba-lbl-deuteranopia',   'deuteranopia'   );
		setTxt( 'mba-lbl-protanopia',     'protanopia'     );
		setTxt( 'mba-lbl-tritanopia',     'tritanopia'     );

		// Text feature buttons
		setTxt( 'mba-lbl-fontsize',       'fontsize'       );
		setTxt( 'mba-lbl-readableFont',   'readableFont'   );
		setTxt( 'mba-lbl-underlineLinks', 'underlineLinks' );
		setTxt( 'mba-lbl-lineHeight',     'lineHeight'     );
		setTxt( 'mba-lbl-textLeft',       'textLeft'       );
		setTxt( 'mba-lbl-letterSpacing',  'letterSpacing'  );

		// Navigation feature buttons  (v2.0)
		setTxt( 'mba-lbl-focusIndicator', 'focusIndicator' );
		setTxt( 'mba-lbl-readingGuide',   'readingGuide'   );
		setTxt( 'mba-lbl-bigCursor',      'bigCursor'      );

		// Screen reader
		setTxt( 'mba-lbl-screenReader',   'screenReader'   );
		setTxt( 'mba-sr-stop-label',      'srStop'         );
		setTxt( 'mba-sr-speed-label',     'srSpeed'        );

		// Aria labels
		const toggle = document.getElementById( 'mba-toggle' );
		if ( toggle ) toggle.setAttribute( 'aria-label', i18n.open || 'Open accessibility menu' );

		const close = document.getElementById( 'mba-close' );
		if ( close ) close.setAttribute( 'aria-label', i18n.close || 'Close' );

		const fontDec = document.getElementById( 'mba-font-dec' );
		if ( fontDec ) fontDec.setAttribute( 'aria-label', i18n.fontDecrease || 'Decrease text size' );

		const fontInc = document.getElementById( 'mba-font-inc' );
		if ( fontInc ) fontInc.setAttribute( 'aria-label', i18n.fontIncrease || 'Increase text size' );

		const spacingDec = document.getElementById( 'mba-spacing-dec' );
		if ( spacingDec ) spacingDec.setAttribute( 'aria-label', i18n.letterDecrease || 'Decrease spacing' );

		const spacingInc = document.getElementById( 'mba-spacing-inc' );
		if ( spacingInc ) spacingInc.setAttribute( 'aria-label', i18n.letterIncrease || 'Increase spacing' );

		// Skip link
		const skipLink = document.getElementById( 'mba-skip-link' );
		if ( skipLink ) skipLink.textContent = i18n.skipToContent || 'Skip to content';
	}

	/* ========================================================================
	   VISIBILITY  (hide disabled features)
	   ======================================================================== */

	function applyFeatureVisibility() {
		const map = {
			// v1
			fontsize:        'mba-fontsize-row',
			highContrast:    'mba-btn-highContrast',
			grayscale:       'mba-btn-grayscale',
			invert:          'mba-btn-invert',
			pauseAnimations: 'mba-btn-pauseAnimations',
			hideImages:      'mba-btn-hideImages',
			readableFont:    'mba-btn-readableFont',
			underlineLinks:  'mba-btn-underlineLinks',
			lineHeight:      'mba-btn-lineHeight',
			screenReader:    'mba-sec-sr',
			// v2.0
			colorblind:      'mba-colorblind-group',
			letterSpacing:   'mba-spacing-row',
			textLeft:        'mba-btn-textLeft',
			focusIndicator:  'mba-btn-focusIndicator',
			readingGuide:    'mba-btn-readingGuide',
			bigCursor:       'mba-btn-bigCursor',
		};

		Object.entries( map ).forEach( ( [ key, id ] ) => {
			const node = document.getElementById( id );
			if ( node && features[ key ] === false ) {
				node.style.display = 'none';
			}
		} );

		// Hide entire sections when all their children are hidden
		[ 'mba-sec-visual', 'mba-sec-text', 'mba-sec-nav' ].forEach( secId => {
			const sec = document.getElementById( secId );
			if ( ! sec ) return;
			const visible = sec.querySelectorAll(
				[
					'button:not([style*="display: none"]):not([style*="display:none"])',
					'.mba-fontsize-row:not([style*="display: none"]):not([style*="display:none"])',
					'.mba-colorblind-group:not([style*="display: none"]):not([style*="display:none"])',
				].join( ', ' )
			);
			if ( ! visible.length ) sec.style.display = 'none';
		} );
	}

	/* ========================================================================
	   EVENT BINDING
	   ======================================================================== */

	function bindEvents() {

		// Toggle panel
		el.toggle.addEventListener( 'click', () => {
			if ( el.panel.classList.contains( 'is-open' ) ) {
				closePanel();
			} else {
				openPanel();
			}
		} );

		// Close button
		if ( el.close ) {
			el.close.addEventListener( 'click', closePanel );
		}

		// Close on Escape
		document.addEventListener( 'keydown', ( e ) => {
			if ( e.key === 'Escape' && el.panel && el.panel.classList.contains( 'is-open' ) ) {
				closePanel();
			}
		} );

		// Click outside to close
		document.addEventListener( 'click', ( e ) => {
			if (
				el.panel &&
				el.panel.classList.contains( 'is-open' ) &&
				! el.panel.contains( e.target ) &&
				! el.toggle.contains( e.target )
			) {
				closePanel();
			}
		} );

		// Feature buttons (delegated on panel body)
		if ( el.panelBody ) {
			el.panelBody.addEventListener( 'click', ( e ) => {
				const btn = e.target.closest( '.mba-feature-btn' );
				if ( ! btn ) return;
				const key = btn.dataset.feature;
				if ( key ) toggleFeature( key );
			} );
		}

		// Reset
		const resetBtn = document.getElementById( 'mba-reset' );
		if ( resetBtn ) resetBtn.addEventListener( 'click', reset );

		// Font size
		if ( el.fontInc ) {
			el.fontInc.addEventListener( 'click', () => {
				if ( state.fontLevel < FONT_LEVELS.length - 1 ) {
					state.fontLevel++;
					applyFontLevel( state.fontLevel );
					saveState();
				}
			} );
		}
		if ( el.fontDec ) {
			el.fontDec.addEventListener( 'click', () => {
				if ( state.fontLevel > 0 ) {
					state.fontLevel--;
					applyFontLevel( state.fontLevel );
					saveState();
				}
			} );
		}

		// Letter spacing (v2.0)
		if ( el.spacingInc ) {
			el.spacingInc.addEventListener( 'click', () => {
				if ( state.spacingLevel < LETTER_LEVELS.length - 1 ) {
					state.spacingLevel++;
					applyLetterSpacing( state.spacingLevel );
					saveState();
				}
			} );
		}
		if ( el.spacingDec ) {
			el.spacingDec.addEventListener( 'click', () => {
				if ( state.spacingLevel > 0 ) {
					state.spacingLevel--;
					applyLetterSpacing( state.spacingLevel );
					saveState();
				}
			} );
		}

		// SR stop
		const srStop = document.getElementById( 'mba-sr-stop' );
		if ( srStop ) srStop.addEventListener( 'click', () => SR.stop() );

		// SR speed slider
		const srSpeed    = document.getElementById( 'mba-sr-speed' );
		const srSpeedVal = document.getElementById( 'mba-sr-speed-val' );
		if ( srSpeed ) {
			srSpeed.value = state.srSpeed || 1;
			srSpeed.addEventListener( 'input', () => {
				state.srSpeed = parseFloat( srSpeed.value );
				if ( srSpeedVal ) {
					srSpeedVal.textContent = state.srSpeed.toFixed( 2 ).replace( /\.?0+$/, '' ) + '×';
				}
				saveState();
			} );
		}
		if ( srSpeedVal ) srSpeedVal.textContent = ( state.srSpeed || 1 ) + '×';
	}

	/* ========================================================================
	   CACHE DOM ELEMENTS
	   ======================================================================== */

	function cacheElements() {
		el.toggle      = document.getElementById( 'mba-toggle' );
		el.panel       = document.getElementById( 'mba-panel' );
		el.close       = document.getElementById( 'mba-close' );
		el.panelBody   = document.querySelector( '#mba-panel .mba-panel-body' );
		el.fontInc     = document.getElementById( 'mba-font-inc' );
		el.fontDec     = document.getElementById( 'mba-font-dec' );
		el.fontCurrent = document.getElementById( 'mba-font-current' );
		el.spacingInc  = document.getElementById( 'mba-spacing-inc' );
		el.spacingDec  = document.getElementById( 'mba-spacing-dec' );
		el.spacingCurrent = document.getElementById( 'mba-spacing-current' );
		el.srStatus    = document.getElementById( 'mba-sr-status' );
		el.srStop      = document.getElementById( 'mba-sr-stop' );
		el.srSpeedWrap = document.getElementById( 'mba-sr-speed-wrap' );

		// Feature buttons (auto-mapped by data-feature attribute)
		el.featureBtns = {};
		document.querySelectorAll( '.mba-feature-btn[data-feature]' ).forEach( btn => {
			el.featureBtns[ btn.dataset.feature ] = btn;
		} );
	}

	/* ========================================================================
	   INIT
	   ======================================================================== */

	function init() {
		const wrapper = document.getElementById( 'mba-widget-wrapper' );
		if ( ! wrapper ) return;

		/**
		 * FIX: CSS `filter` on <body> creates a new stacking context that
		 * breaks `position:fixed` children (widget scrolls with page).
		 * Workaround: move widget to <html>, which is outside the filtered body.
		 */
		document.documentElement.appendChild( wrapper );

		// Inject SVG colorblind filters into <body> (before widget moves out)
		injectSVGFilters();

		// Apply correct position class (desktop vs mobile)
		applyPositionClass();

		// ── Skip-link target fix (WCAG 2.4.1 / Lighthouse bypass audit) ──────────
		// Guarantee the skip link always has a focusable target, regardless of theme.
		( function initSkipTarget() {
			const skipLink = document.getElementById( 'mba-skip-link' );
			if ( ! skipLink ) return;

			const configuredId = ( skipLink.getAttribute( 'href' ) || '' ).replace( /^#/, '' );
			let target = configuredId ? document.getElementById( configuredId ) : null;

			// Roles that disqualify an element from being a skip-link target.
			const BAD_ROLES = [ 'listitem', 'list', 'gridcell', 'row', 'rowgroup',
				'columnheader', 'rowheader', 'cell', 'presentation', 'none' ];

			function isValidTarget( el ) {
				if ( ! el ) return false;
				if ( el.closest( '#mba-widget-wrapper' ) ) return false;
				const role = ( el.getAttribute( 'role' ) || '' ).trim().toLowerCase();
				return role === '' || ! BAD_ROLES.includes( role );
			}

			// If the configured target doesn't exist, find the real main content.
			if ( ! target || ! isValidTarget( target ) ) {
				target = null; // reset in case it existed but had a bad role
				const candidates = [
					'main',
					'[role="main"]',
					'#main',
					'#primary',
					'#site-content',
					'#page-content',
					'.site-main',
					'.main-content',
					'#content',
					'#page',
					'.page',
					'#wrapper',
					'.wrapper',
				];
				for ( let i = 0; i < candidates.length; i++ ) {
					const el = document.querySelector( candidates[ i ] );
					if ( el && isValidTarget( el ) ) {
						target = el;
						break;
					}
				}

				if ( target ) {
					// Give it a stable ID so the href points to something real.
					if ( ! target.id ) {
						target.id = 'mba-main-content';
					}
					skipLink.setAttribute( 'href', '#' + target.id );
				}
			}

			// Make the target programmatically focusable.
			if ( target ) {
				if ( ! target.hasAttribute( 'tabindex' ) ) {
					target.setAttribute( 'tabindex', '-1' );
				}
				// Suppress the focus ring on the container itself (aesthetic only).
				target.style.outline = 'none';
			}
		}() );

		cacheElements();
		setLabels();
		loadState();
		applyFeatureVisibility();
		applyAllState();
		bindEvents();

		// Update position class on viewport resize (e.g. device rotation)
		window.addEventListener( 'resize', applyPositionClass );

		// Sync SR speed display
		const srSpeedVal   = document.getElementById( 'mba-sr-speed-val' );
		const srSpeedInput = document.getElementById( 'mba-sr-speed' );
		if ( srSpeedInput ) srSpeedInput.value = state.srSpeed || 1;
		if ( srSpeedVal   ) srSpeedVal.textContent = ( state.srSpeed || 1 ) + '×';

		// Voices may load async in Chrome
		if ( 'speechSynthesis' in window ) {
			window.speechSynthesis.onvoiceschanged = () => {};
		}
	}

	/* ========================================================================
	   BOOT
	   ======================================================================== */

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

} )();
