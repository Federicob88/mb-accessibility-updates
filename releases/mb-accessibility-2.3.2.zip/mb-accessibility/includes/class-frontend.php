<?php
/**
 * MB Accessibility – Frontend: enqueue assets, render widget, skip link.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MBA_Frontend {

	/** @var array */
	private array $s;

	public function __construct() {
		$this->s = MBA_Plugin::get_settings();

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'wp_body_open',       array( $this, 'render_skip_link' ), 1 );
		add_action( 'wp_footer',          array( $this, 'render_widget' ),   20 );
	}

	// -----------------------------------------------------------------------
	// Assets
	// -----------------------------------------------------------------------

	public function enqueue(): void {
		wp_enqueue_style(
			'mba-features',
			MBA_URL . 'assets/css/features.css',
			array(),
			MBA_VERSION
		);
		wp_enqueue_style(
			'mba-widget',
			MBA_URL . 'assets/css/widget.css',
			array( 'mba-features' ),
			MBA_VERSION
		);
		wp_enqueue_script(
			'mba-widget',
			MBA_URL . 'assets/js/widget.js',
			array(),
			MBA_VERSION,
			true
		);

		// Dynamic colour overrides (inline, minimal)
		$color = sanitize_hex_color( $this->s['color'] ) ?: '#1a6baa';
		wp_add_inline_style( 'mba-widget', $this->color_css( $color ) );

		// Pass configuration + i18n strings to JS
		wp_localize_script( 'mba-widget', 'mbaConfig', array(
			'position'           => $this->s['position'],
			'positionMobile'     => $this->s['position_mobile'] ?? 'right',
			'showOnMobile'       => $this->s['show_on_mobile'] === '1',
			'srEnabled'          => $this->s['screen_reader_enabled'] === '1',
			'srMode'             => $this->s['screen_reader_mode'],
			'statementUrl'       => $this->s['accessibility_statement_url'],
			'features'           => $this->enabled_features(),
			'expiration'         => 24,   // hours for localStorage
			'readingGuideHeight' => (int) ( $this->s['reading_guide_height'] ?? 22 ),
			'i18n'               => $this->i18n_strings(),
		) );
	}

	// -----------------------------------------------------------------------
	// Colour CSS
	// -----------------------------------------------------------------------

	private function color_css( string $color ): string {
		$rgb = $this->hex_to_rgb( $color );

		// Colore scuro reale (~18% più scuro) per hover/focus
		$rd   = max( 0, (int) round( $rgb['r'] * 0.82 ) );
		$gd   = max( 0, (int) round( $rgb['g'] * 0.82 ) );
		$bd   = max( 0, (int) round( $rgb['b'] * 0.82 ) );
		$dark  = "rgb({$rd},{$gd},{$bd})";
		$alpha = "rgba({$rgb['r']},{$rgb['g']},{$rgb['b']},0.12)";

		return "
			:root { --mba-color: {$color}; --mba-color-dark: {$dark}; --mba-color-alpha: {$alpha}; }

			/* Toggle button */
			#mba-toggle { background: {$color} !important; }
			#mba-toggle:hover,
			#mba-toggle:focus { background: {$dark} !important; }

			/* Panel header */
			.mba-panel-header { background: {$color} !important; }

			/* Feature buttons – default hover/focus (non attivo) */
			.mba-feature-btn:hover,
			.mba-feature-btn:focus {
				border-color: {$color} !important;
				background: {$alpha} !important;
				color: inherit !important;
			}

			/* Feature buttons – stato attivo */
			.mba-feature-btn.is-active,
			.mba-feature-btn[aria-pressed=\"true\"] {
				background: {$color} !important;
				border-color: {$color} !important;
				color: #fff !important;
			}

			/*
			 * FIX CONTRASTO: pulsante attivo + hover/focus.
			 * Questa regola viene per ultima e sovrascrive il :hover generico.
			 * Mantiene sfondo solido + testo bianco, scurisce leggermente.
			 */
			.mba-feature-btn.is-active:hover,
			.mba-feature-btn.is-active:focus,
			.mba-feature-btn[aria-pressed=\"true\"]:hover,
			.mba-feature-btn[aria-pressed=\"true\"]:focus {
				background: {$dark} !important;
				border-color: {$dark} !important;
				color: #fff !important;
			}

			/* Font / spacing controls */
			.mba-font-btn:hover,
			.mba-font-btn:focus { color: {$color} !important; }

			/* Reset button */
			.mba-reset-btn:hover,
			.mba-reset-btn:focus { color: {$color} !important; border-color: {$color} !important; }

			/* Footer statement link */
			.mba-statement-link { color: {$color} !important; }
			.mba-statement-link:hover { text-decoration: underline !important; }

			/* SR speed slider thumb */
			#mba-sr-speed::-webkit-slider-thumb { background: {$color}; }
			#mba-sr-speed::-moz-range-thumb { background: {$color}; }
		";
	}

	private function hex_to_rgb( string $hex ): array {
		$hex = ltrim( $hex, '#' );
		if ( strlen( $hex ) === 3 ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		return array(
			'r' => hexdec( substr( $hex, 0, 2 ) ),
			'g' => hexdec( substr( $hex, 2, 2 ) ),
			'b' => hexdec( substr( $hex, 4, 2 ) ),
		);
	}

	// -----------------------------------------------------------------------
	// Features list
	// -----------------------------------------------------------------------

	private function enabled_features(): array {
		return array(
			// v1
			'fontsize'        => $this->s['features_font_size']        === '1',
			'highContrast'    => $this->s['features_high_contrast']    === '1',
			'grayscale'       => $this->s['features_grayscale']        === '1',
			'invert'          => $this->s['features_invert']           === '1',
			'readableFont'    => $this->s['features_readable_font']    === '1',
			'underlineLinks'  => $this->s['features_underline_links']  === '1',
			'pauseAnimations' => $this->s['features_pause_animations'] === '1',
			'hideImages'      => $this->s['features_hide_images']      === '1',
			'lineHeight'      => $this->s['features_line_height']      === '1',
			'screenReader'    => $this->s['screen_reader_enabled']     === '1',
			// v2.0
			'colorblind'      => $this->s['features_colorblind']      === '1',
			'letterSpacing'   => $this->s['features_letter_spacing']  === '1',
			'textLeft'        => $this->s['features_text_left']       === '1',
			'focusIndicator'  => $this->s['features_focus_indicator'] === '1',
			'readingGuide'    => $this->s['features_reading_guide']   === '1',
			'bigCursor'       => $this->s['features_big_cursor']      === '1',
		);
	}

	// -----------------------------------------------------------------------
	// i18n strings (6 languages)
	// -----------------------------------------------------------------------

	private function i18n_strings(): array {
		$locale = get_locale();

		$map = array(
			'it' => 'it', 'it_IT' => 'it', 'it_CH' => 'it',
			'fr' => 'fr', 'fr_FR' => 'fr', 'fr_CH' => 'fr', 'fr_BE' => 'fr',
			'de' => 'de', 'de_DE' => 'de', 'de_CH' => 'de', 'de_AT' => 'de',
			'es' => 'es', 'es_ES' => 'es', 'es_MX' => 'es', 'es_AR' => 'es',
			'ru' => 'ru', 'ru_RU' => 'ru',
		);
		$lang = $map[ $locale ] ?? 'en';

		$all = array(

			// ------------------------------------------------------------------
			'en' => array(
				'panelTitle'        => 'Accessibility',
				'open'              => 'Open accessibility menu',
				'close'             => 'Close',
				'reset'             => 'Reset settings',
				'sectionVisual'     => 'Visual',
				'sectionText'       => 'Text',
				'sectionNav'        => 'Navigation',
				'sectionSR'         => 'Screen Reader',
				'highContrast'      => 'High Contrast',
				'grayscale'         => 'Grayscale',
				'invert'            => 'Neg. Contrast',
				'pauseAnimations'   => 'Pause Anim.',
				'hideImages'        => 'Hide Images',
				'deuteranopia'      => 'Deuteranopia',
				'protanopia'        => 'Protanopia',
				'tritanopia'        => 'Tritanopia',
				'colorblindHint'    => 'Color blindness profiles',
				'fontsize'          => 'Text Size',
				'fontIncrease'      => 'Increase text size',
				'fontDecrease'      => 'Decrease text size',
				'readableFont'      => 'Readable Font',
				'underlineLinks'    => 'Underline Links',
				'lineHeight'        => 'Line Height',
				'letterSpacing'     => 'Text Spacing',
				'letterIncrease'    => 'Increase spacing',
				'letterDecrease'    => 'Decrease spacing',
				'textLeft'          => 'Align Left',
				'focusIndicator'    => 'Focus Visible',
				'readingGuide'      => 'Reading Guide',
				'bigCursor'         => 'Large Cursor',
				'screenReader'      => 'Screen Reader',
				'srClickPrompt'     => 'Click on any text to read it aloud',
				'srHoverPrompt'     => 'Hover over text to read it aloud',
				'srReading'         => 'Reading…',
				'srStop'            => 'Stop',
				'srNotSupported'    => 'Not supported in this browser',
				'srSpeed'           => 'Reading speed',
				'statement'         => 'Accessibility Statement',
				'skipToContent'     => 'Skip to content',
			),

			// ------------------------------------------------------------------
			'it' => array(
				'panelTitle'        => 'Accessibilità',
				'open'              => 'Apri menu accessibilità',
				'close'             => 'Chiudi',
				'reset'             => 'Ripristina impostazioni',
				'sectionVisual'     => 'Visivo',
				'sectionText'       => 'Testo',
				'sectionNav'        => 'Navigazione',
				'sectionSR'         => 'Lettore schermo',
				'highContrast'      => 'Alto contrasto',
				'grayscale'         => 'Scala di grigi',
				'invert'            => 'Contrasto neg.',
				'pauseAnimations'   => 'Blocca animaz.',
				'hideImages'        => 'Nascondi imm.',
				'deuteranopia'      => 'Deuteranopia',
				'protanopia'        => 'Protanopia',
				'tritanopia'        => 'Tritanopia',
				'colorblindHint'    => 'Profili daltonismo',
				'fontsize'          => 'Dim. testo',
				'fontIncrease'      => 'Aumenta dimensione testo',
				'fontDecrease'      => 'Riduci dimensione testo',
				'readableFont'      => 'Font leggibile',
				'underlineLinks'    => 'Sottolinea link',
				'lineHeight'        => 'Interlinea',
				'letterSpacing'     => 'Spaziatura',
				'letterIncrease'    => 'Aumenta spaziatura',
				'letterDecrease'    => 'Riduci spaziatura',
				'textLeft'          => 'Allinea sinistra',
				'focusIndicator'    => 'Focus visibile',
				'readingGuide'      => 'Guida lettura',
				'bigCursor'         => 'Cursore grande',
				'screenReader'      => 'Lettore schermo',
				'srClickPrompt'     => 'Clicca su un testo per ascoltarlo',
				'srHoverPrompt'     => 'Passa il mouse su un testo per ascoltarlo',
				'srReading'         => 'Lettura in corso…',
				'srStop'            => 'Interrompi',
				'srNotSupported'    => 'Non supportato da questo browser',
				'srSpeed'           => 'Velocità lettura',
				'statement'         => 'Dichiarazione di accessibilità',
				'skipToContent'     => 'Vai al contenuto',
			),

			// ------------------------------------------------------------------
			'fr' => array(
				'panelTitle'        => 'Accessibilité',
				'open'              => "Ouvrir le menu d'accessibilité",
				'close'             => 'Fermer',
				'reset'             => 'Réinitialiser',
				'sectionVisual'     => 'Visuel',
				'sectionText'       => 'Texte',
				'sectionNav'        => 'Navigation',
				'sectionSR'         => "Lecteur d'écran",
				'highContrast'      => 'Contraste élevé',
				'grayscale'         => 'Niveaux de gris',
				'invert'            => 'Contraste nég.',
				'pauseAnimations'   => 'Pause anim.',
				'hideImages'        => 'Masquer images',
				'deuteranopia'      => 'Deutéranopie',
				'protanopia'        => 'Protanopie',
				'tritanopia'        => 'Tritanopie',
				'colorblindHint'    => 'Profils daltonisme',
				'fontsize'          => 'Taille du texte',
				'fontIncrease'      => 'Agrandir le texte',
				'fontDecrease'      => 'Réduire le texte',
				'readableFont'      => 'Police lisible',
				'underlineLinks'    => 'Souligner les liens',
				'lineHeight'        => 'Interligne',
				'letterSpacing'     => 'Espacement',
				'letterIncrease'    => 'Augmenter espacement',
				'letterDecrease'    => 'Réduire espacement',
				'textLeft'          => 'Aligner à gauche',
				'focusIndicator'    => 'Focus visible',
				'readingGuide'      => 'Guide lecture',
				'bigCursor'         => 'Grand curseur',
				'screenReader'      => "Lecteur d'écran",
				'srClickPrompt'     => 'Cliquez sur un texte pour le lire',
				'srHoverPrompt'     => 'Survolez un texte pour le lire',
				'srReading'         => 'Lecture…',
				'srStop'            => 'Arrêter',
				'srNotSupported'    => 'Non pris en charge par ce navigateur',
				'srSpeed'           => 'Vitesse de lecture',
				'statement'         => "Déclaration d'accessibilité",
				'skipToContent'     => 'Aller au contenu',
			),

			// ------------------------------------------------------------------
			'de' => array(
				'panelTitle'        => 'Barrierefreiheit',
				'open'              => 'Barrierefreiheitsmenü öffnen',
				'close'             => 'Schließen',
				'reset'             => 'Zurücksetzen',
				'sectionVisual'     => 'Visuell',
				'sectionText'       => 'Text',
				'sectionNav'        => 'Navigation',
				'sectionSR'         => 'Vorlesen',
				'highContrast'      => 'Hoher Kontrast',
				'grayscale'         => 'Graustufen',
				'invert'            => 'Neg. Kontrast',
				'pauseAnimations'   => 'Anim. pausieren',
				'hideImages'        => 'Bilder ausblend.',
				'deuteranopia'      => 'Deuteranopie',
				'protanopia'        => 'Protanopie',
				'tritanopia'        => 'Tritanopie',
				'colorblindHint'    => 'Farbenblindheitsprofile',
				'fontsize'          => 'Schriftgröße',
				'fontIncrease'      => 'Text vergrößern',
				'fontDecrease'      => 'Text verkleinern',
				'readableFont'      => 'Lesbare Schrift',
				'underlineLinks'    => 'Links unterstreichen',
				'lineHeight'        => 'Zeilenabstand',
				'letterSpacing'     => 'Zeichenabstand',
				'letterIncrease'    => 'Abstand erhöhen',
				'letterDecrease'    => 'Abstand verringern',
				'textLeft'          => 'Links ausrichten',
				'focusIndicator'    => 'Fokus sichtbar',
				'readingGuide'      => 'Leseführung',
				'bigCursor'         => 'Großer Cursor',
				'screenReader'      => 'Bildschirmleser',
				'srClickPrompt'     => 'Klicken Sie auf Text, um ihn vorlesen zu lassen',
				'srHoverPrompt'     => 'Fahren Sie über Text zum Vorlesen',
				'srReading'         => 'Wird gelesen…',
				'srStop'            => 'Stopp',
				'srNotSupported'    => 'Nicht von diesem Browser unterstützt',
				'srSpeed'           => 'Lesegeschwindigkeit',
				'statement'         => 'Barrierefreiheitserklärung',
				'skipToContent'     => 'Zum Inhalt springen',
			),

			// ------------------------------------------------------------------
			'es' => array(
				'panelTitle'        => 'Accesibilidad',
				'open'              => 'Abrir menú de accesibilidad',
				'close'             => 'Cerrar',
				'reset'             => 'Restablecer',
				'sectionVisual'     => 'Visual',
				'sectionText'       => 'Texto',
				'sectionNav'        => 'Navegación',
				'sectionSR'         => 'Lector de pantalla',
				'highContrast'      => 'Alto contraste',
				'grayscale'         => 'Escala de grises',
				'invert'            => 'Contraste neg.',
				'pauseAnimations'   => 'Pausar anim.',
				'hideImages'        => 'Ocultar imág.',
				'deuteranopia'      => 'Deuteranopía',
				'protanopia'        => 'Protanopía',
				'tritanopia'        => 'Tritanopía',
				'colorblindHint'    => 'Perfiles daltonismo',
				'fontsize'          => 'Tamaño texto',
				'fontIncrease'      => 'Aumentar texto',
				'fontDecrease'      => 'Reducir texto',
				'readableFont'      => 'Fuente legible',
				'underlineLinks'    => 'Subrayar enlaces',
				'lineHeight'        => 'Interlineado',
				'letterSpacing'     => 'Espaciado',
				'letterIncrease'    => 'Aumentar espaciado',
				'letterDecrease'    => 'Reducir espaciado',
				'textLeft'          => 'Alinear izquierda',
				'focusIndicator'    => 'Foco visible',
				'readingGuide'      => 'Guía lectura',
				'bigCursor'         => 'Cursor grande',
				'screenReader'      => 'Lector de pantalla',
				'srClickPrompt'     => 'Haga clic en el texto para escucharlo',
				'srHoverPrompt'     => 'Pase el cursor sobre el texto para escucharlo',
				'srReading'         => 'Leyendo…',
				'srStop'            => 'Detener',
				'srNotSupported'    => 'No compatible con este navegador',
				'srSpeed'           => 'Velocidad de lectura',
				'statement'         => 'Declaración de accesibilidad',
				'skipToContent'     => 'Ir al contenido',
			),

			// ------------------------------------------------------------------
			'ru' => array(
				'panelTitle'        => 'Доступность',
				'open'              => 'Открыть меню доступности',
				'close'             => 'Закрыть',
				'reset'             => 'Сбросить',
				'sectionVisual'     => 'Визуальный',
				'sectionText'       => 'Текст',
				'sectionNav'        => 'Навигация',
				'sectionSR'         => 'Диктор',
				'highContrast'      => 'Выс. контраст',
				'grayscale'         => 'Оттенки серого',
				'invert'            => 'Негат. контраст',
				'pauseAnimations'   => 'Стоп анимации',
				'hideImages'        => 'Скрыть изобр.',
				'deuteranopia'      => 'Дейтеранопия',
				'protanopia'        => 'Протанопия',
				'tritanopia'        => 'Тританопия',
				'colorblindHint'    => 'Профили дальтонизма',
				'fontsize'          => 'Размер текста',
				'fontIncrease'      => 'Увеличить текст',
				'fontDecrease'      => 'Уменьшить текст',
				'readableFont'      => 'Читаемый шрифт',
				'underlineLinks'    => 'Подчеркнуть ссылки',
				'lineHeight'        => 'Межстрочный интервал',
				'letterSpacing'     => 'Межзнаковый интервал',
				'letterIncrease'    => 'Увеличить интервал',
				'letterDecrease'    => 'Уменьшить интервал',
				'textLeft'          => 'По левому краю',
				'focusIndicator'    => 'Видимый фокус',
				'readingGuide'      => 'Линейка чтения',
				'bigCursor'         => 'Большой курсор',
				'screenReader'      => 'Экранный диктор',
				'srClickPrompt'     => 'Нажмите на текст, чтобы услышать его',
				'srHoverPrompt'     => 'Наведите курсор на текст для озвучивания',
				'srReading'         => 'Идёт чтение…',
				'srStop'            => 'Стоп',
				'srNotSupported'    => 'Не поддерживается этим браузером',
				'srSpeed'           => 'Скорость чтения',
				'statement'         => 'Заявление о доступности',
				'skipToContent'     => 'Перейти к содержимому',
			),
		);

		return $all[ $lang ] ?? $all['en'];
	}

	// -----------------------------------------------------------------------
	// Skip-to-content link
	// -----------------------------------------------------------------------

	public function render_skip_link(): void {
		if ( $this->s['skip_to_content'] !== '1' ) {
			return;
		}
		$target = '#' . sanitize_html_class( $this->s['skip_to_content_target'] ?: 'content' );
		// Label will be overwritten by JS with the correct locale string.
		printf(
			'<a id="mba-skip-link" class="mba-skip-link" href="%s">Skip to content</a>',
			esc_attr( $target )
		);
	}

	// -----------------------------------------------------------------------
	// Widget HTML
	// -----------------------------------------------------------------------

	public function render_widget(): void {
		$s        = $this->s;
		$pos_cls  = 'mba-pos-' . esc_attr( $s['position'] );
		$mob_cls  = $s['show_on_mobile'] === '0' ? ' mba-hide-mobile' : '';
		$stmt_url = $s['accessibility_statement_url'];
		?>

		<div id="mba-widget-wrapper"
		     class="<?php echo $pos_cls . $mob_cls; ?>"
		     role="region"
		     aria-label="Accessibility Tools">

			<!-- ============================================================
			     TOGGLE BUTTON (floating)
			     ============================================================ -->
			<button id="mba-toggle"
			        type="button"
			        aria-expanded="false"
			        aria-controls="mba-panel"
			        aria-label="Open accessibility menu">
				<?php
				if ( ! empty( $s['toggle_icon_url'] ) ) :
					// 1. Icona personalizzata caricata dall'utente (priorita' massima)
				?>
				<img src="<?php echo esc_url( $s['toggle_icon_url'] ); ?>"
				     alt=""
				     aria-hidden="true"
				     focusable="false"
				     class="mba-toggle-img">
				<?php else :
					// 2. Preset colore (default: arancione)
					$preset     = $s['toggle_icon_preset'] ?? 'arancione';
					$allowed    = array( 'arancione', 'rosso', 'rosa', 'blu', 'verde' );
					$preset     = in_array( $preset, $allowed, true ) ? $preset : 'arancione';
					$preset_url = MBA_URL . 'assets/images/mba-icon-' . $preset . '.webp';
				?>
				<img src="<?php echo esc_url( $preset_url ); ?>"
				     alt=""
				     aria-hidden="true"
				     focusable="false"
				     class="mba-toggle-img">
				<?php endif; ?>
			</button>

			<!-- ============================================================
			     PANEL
			     ============================================================ -->
			<div id="mba-panel"
			     role="dialog"
			     aria-modal="true"
			     aria-labelledby="mba-panel-title"
			     aria-hidden="true">

				<!-- Header -->
				<div class="mba-panel-header">
					<span id="mba-panel-title" class="mba-panel-title"></span>
					<button type="button" id="mba-close" class="mba-close" aria-label="Close">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
						</svg>
					</button>
				</div>

				<!-- Body -->
				<div class="mba-panel-body">

					<!-- Reset -->
					<button type="button" class="mba-reset-btn" id="mba-reset">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
							<path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
						</svg>
						<span id="mba-reset-label"></span>
					</button>

					<!-- ---- SECTION: VISUAL ---- -->
					<div class="mba-section" id="mba-sec-visual">
						<div class="mba-section-title" id="mba-sec-visual-label"></div>
						<div class="mba-features-grid">

							<!-- High Contrast -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-highContrast"
							        data-feature="highContrast"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 100 18A9 9 0 0012 3zm0 16V5a7 7 0 010 14z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-highContrast"></span>
							</button>

							<!-- Grayscale -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-grayscale"
							        data-feature="grayscale"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M12 3C7.03 3 3 7.03 3 12s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9zm0 16V5c3.87 0 7 3.13 7 7s-3.13 7-7 7z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-grayscale"></span>
							</button>

							<!-- Invert -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-invert"
							        data-feature="invert"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 100 18A9 9 0 0012 3zm0 14.5V6.5a5.5 5.5 0 010 11z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-invert"></span>
							</button>

							<!-- Pause Animations -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-pauseAnimations"
							        data-feature="pauseAnimations"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-pauseAnimations"></span>
							</button>

							<!-- Hide Images -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-hideImages"
							        data-feature="hideImages"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-hideImages"></span>
							</button>

						</div>

						<!-- Colorblind profiles sub-section -->
						<div class="mba-colorblind-group" id="mba-colorblind-group">
							<div class="mba-subsection-title" id="mba-lbl-colorblindHint"></div>
							<div class="mba-features-grid mba-features-grid--3">

								<!-- Deuteranopia (rosso-verde) -->
								<button type="button"
								        class="mba-feature-btn mba-feature-btn--sm"
								        id="mba-btn-deuteranopia"
								        data-feature="deuteranopia"
								        aria-pressed="false">
									<span class="mba-feature-icon" aria-hidden="true">
										<svg viewBox="0 0 24 24"><circle cx="8" cy="12" r="5" fill="#e74c3c" opacity=".6"/><circle cx="16" cy="12" r="5" fill="#27ae60" opacity=".6"/><line x1="12" y1="7" x2="12" y2="17" stroke="#fff" stroke-width="1.5"/></svg>
									</span>
									<span class="mba-feature-label" id="mba-lbl-deuteranopia"></span>
								</button>

								<!-- Protanopia (rosso) -->
								<button type="button"
								        class="mba-feature-btn mba-feature-btn--sm"
								        id="mba-btn-protanopia"
								        data-feature="protanopia"
								        aria-pressed="false">
									<span class="mba-feature-icon" aria-hidden="true">
										<svg viewBox="0 0 24 24"><circle cx="8" cy="12" r="5" fill="#c0392b" opacity=".5"/><circle cx="16" cy="12" r="5" fill="#888" opacity=".6"/><line x1="12" y1="7" x2="12" y2="17" stroke="#fff" stroke-width="1.5"/></svg>
									</span>
									<span class="mba-feature-label" id="mba-lbl-protanopia"></span>
								</button>

								<!-- Tritanopia (blu-giallo) -->
								<button type="button"
								        class="mba-feature-btn mba-feature-btn--sm"
								        id="mba-btn-tritanopia"
								        data-feature="tritanopia"
								        aria-pressed="false">
									<span class="mba-feature-icon" aria-hidden="true">
										<svg viewBox="0 0 24 24"><circle cx="8" cy="12" r="5" fill="#2980b9" opacity=".6"/><circle cx="16" cy="12" r="5" fill="#f1c40f" opacity=".6"/><line x1="12" y1="7" x2="12" y2="17" stroke="#fff" stroke-width="1.5"/></svg>
									</span>
									<span class="mba-feature-label" id="mba-lbl-tritanopia"></span>
								</button>

							</div>
						</div>

					</div><!-- /mba-sec-visual -->

					<!-- ---- SECTION: TEXT ---- -->
					<div class="mba-section" id="mba-sec-text">
						<div class="mba-section-title" id="mba-sec-text-label"></div>
						<div class="mba-features-grid">

							<!-- Font Size -->
							<div class="mba-fontsize-row" id="mba-fontsize-row">
								<span class="mba-fontsize-label" id="mba-lbl-fontsize"></span>
								<div class="mba-fontsize-controls">
									<button type="button" class="mba-font-btn" id="mba-font-dec" aria-label="Decrease text size">
										<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M19 13H5v-2h14v2z"/></svg>
										<span>A</span>
									</button>
									<span class="mba-font-current" id="mba-font-current" aria-live="polite">100%</span>
									<button type="button" class="mba-font-btn" id="mba-font-inc" aria-label="Increase text size">
										<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
										<span>A</span>
									</button>
								</div>
							</div>

							<!-- Readable Font -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-readableFont"
							        data-feature="readableFont"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M9.62 12H14.38L12 5.67 9.62 12zM11 3L5.5 17H7.75L8.87 14H15.12L16.25 17H18.5L13 3H11z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-readableFont"></span>
							</button>

							<!-- Underline Links -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-underlineLinks"
							        data-feature="underlineLinks"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M12 17c3.31 0 6-2.69 6-6V3h-2.5v8c0 1.93-1.57 3.5-3.5 3.5S8.5 12.93 8.5 11V3H6v8c0 3.31 2.69 6 6 6zm-7 2v2h14v-2H5z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-underlineLinks"></span>
							</button>

							<!-- Line Height -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-lineHeight"
							        data-feature="lineHeight"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M6 7h2.5L5 3.5 1.5 7H4v10H1.5L5 20.5 8.5 17H6V7zm4 2v2h12V9H10zm0 6h12v-2H10v2z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-lineHeight"></span>
							</button>

							<!-- Text Left Align -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-textLeft"
							        data-feature="textLeft"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M15 15H3v2h12v-2zm0-8H3v2h12V7zM3 13h18v-2H3v2zm0 8h18v-2H3v2zM3 3v2h18V3H3z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-textLeft"></span>
							</button>

						</div>

						<!-- Letter Spacing control -->
						<div class="mba-fontsize-row" id="mba-spacing-row">
							<span class="mba-fontsize-label" id="mba-lbl-letterSpacing"></span>
							<div class="mba-fontsize-controls">
								<button type="button" class="mba-font-btn" id="mba-spacing-dec" aria-label="">
									<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M19 13H5v-2h14v2z"/></svg>
									<span>A</span>
								</button>
								<span class="mba-font-current" id="mba-spacing-current" aria-live="polite">Std</span>
								<button type="button" class="mba-font-btn" id="mba-spacing-inc" aria-label="">
									<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
									<span>A</span>
								</button>
							</div>
						</div>

					</div><!-- /mba-sec-text -->

					<!-- ---- SECTION: NAVIGATION (v2.0) ---- -->
					<div class="mba-section" id="mba-sec-nav">
						<div class="mba-section-title" id="mba-sec-nav-label"></div>
						<div class="mba-features-grid">

							<!-- Focus Indicator -->
							<button type="button"
							        class="mba-feature-btn"
							        id="mba-btn-focusIndicator"
							        data-feature="focusIndicator"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-focusIndicator"></span>
							</button>

							<!-- Reading Guide (hidden on touch devices – no cursor to guide) -->
							<button type="button"
							        class="mba-feature-btn mba-desktop-only"
							        id="mba-btn-readingGuide"
							        data-feature="readingGuide"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-readingGuide"></span>
							</button>

							<!-- Big Cursor (hidden on touch devices via CSS) -->
							<button type="button"
							        class="mba-feature-btn mba-desktop-only"
							        id="mba-btn-bigCursor"
							        data-feature="bigCursor"
							        aria-pressed="false">
								<span class="mba-feature-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24"><path d="M4 0l16 12.3-6.4 1-3 5.3-1.7-8.1z"/></svg>
								</span>
								<span class="mba-feature-label" id="mba-lbl-bigCursor"></span>
							</button>

						</div>
					</div><!-- /mba-sec-nav -->

					<!-- ---- SECTION: SCREEN READER ---- -->
					<div class="mba-section" id="mba-sec-sr">
						<div class="mba-section-title" id="mba-sec-sr-label"></div>

						<button type="button"
						        class="mba-feature-btn mba-sr-toggle-btn"
						        id="mba-btn-screenReader"
						        data-feature="screenReader"
						        aria-pressed="false">
							<span class="mba-feature-icon" aria-hidden="true">
								<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
							</span>
							<span class="mba-feature-label" id="mba-lbl-screenReader"></span>
						</button>

						<!-- Status message -->
						<div class="mba-sr-status" id="mba-sr-status" aria-live="polite" aria-atomic="true"></div>

						<!-- Stop button (visible when reading) -->
						<button type="button" class="mba-sr-stop-btn" id="mba-sr-stop" style="display:none;">
							<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6h12v12H6z"/></svg>
							<span id="mba-sr-stop-label"></span>
						</button>

						<!-- Speed control (visible when SR active) -->
						<div class="mba-sr-speed" id="mba-sr-speed-wrap" style="display:none;">
							<label for="mba-sr-speed" id="mba-sr-speed-label">
								<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/></svg>
							</label>
							<input type="range"
							       id="mba-sr-speed"
							       min="0.5"
							       max="2"
							       step="0.25"
							       value="1">
							<span id="mba-sr-speed-val">1×</span>
						</div>

					</div><!-- /mba-sec-sr -->

				</div><!-- /mba-panel-body -->

				<!-- ============================================================
				     FOOTER – Accessibility Statement link
				     ============================================================ -->
				<?php if ( ! empty( $stmt_url ) ) : ?>
				<div class="mba-panel-footer">
					<a href="<?php echo esc_url( $stmt_url ); ?>"
					   id="mba-statement-link"
					   class="mba-statement-link"
					   target="_blank"
					   rel="noopener noreferrer">
						<svg viewBox="0 0 24 24" width="11" height="11" aria-hidden="true" focusable="false">
							<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
						</svg>
						<span id="mba-statement-text"></span>
					</a>
				</div>
				<?php endif; ?>

			</div><!-- /mba-panel -->

		</div><!-- /mba-widget-wrapper -->

		<?php
	}
}
