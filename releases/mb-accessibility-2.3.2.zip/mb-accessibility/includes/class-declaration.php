<?php
/**
 * MB Accessibility – Accessibility Declaration.
 *
 * Registers the [mba_dichiarazione] shortcode and handles
 * the "Create / Update page" admin action.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MBA_Declaration {

	public function __construct() {
		add_shortcode( 'mba_dichiarazione', array( $this, 'render_shortcode' ) );
		add_action( 'admin_post_mba_create_declaration_page', array( $this, 'handle_create_page' ) );
	}

	// -----------------------------------------------------------------------
	// Multilingual string tables (IT, EN, DE, FR, RU)
	// -----------------------------------------------------------------------

	private function get_strings( string $lang ): array {
		$all = array(
			'it' => array(
				'title'               => 'Dichiarazione di accessibilità',
				'legal_ref'           => 'Redatta ai sensi del D.Lgs. 10 agosto 2018, n. 106 (recepimento Direttiva UE 2016/2102)',
				'section_commitment'  => "Impegno per l'accessibilità",
				'commitment_text'     => '<strong>%1$s</strong> si impegna a rendere il proprio sito web <a href="%2$s">%2$s</a> accessibile, in conformità con le Linee guida WCAG 2.1 livello AA e la normativa vigente.',
				'section_status'      => 'Stato di conformità',
				'evaluated_text'      => "Il sito è stato valutato rispetto alle Linee guida per l'accessibilità dei contenuti Web (WCAG) 2.1, livello AA.",
				'status_conforme'     => 'Pienamente conforme',
				'status_parzialmente' => 'Parzialmente conforme',
				'status_non_conforme' => 'Non conforme',
				'status_onere'        => 'Parzialmente conforme – con onere sproporzionato',
				'section_issues'      => 'Contenuti non accessibili',
				'issues_intro'        => 'I seguenti criteri WCAG non sono al momento pienamente soddisfatti:',
				'section_burden'      => 'Onere sproporzionato',
				'section_widget'      => 'Misure compensative adottate – Widget di accessibilità',
				'widget_intro'        => "Il sito integra un widget di accessibilità che fornisce agli utenti strumenti per personalizzare l'esperienza di navigazione e compensare alcune limitazioni presenti nei contenuti. Le funzionalità attive mitigano i seguenti criteri WCAG:",
				'th_criterion'        => 'Criterio',
				'th_description'      => 'Descrizione',
				'th_tool'             => 'Strumento fornito',
				'section_contact'     => 'Segnalazioni e contenuti alternativi',
				'contact_with_url'    => 'Per segnalare problemi di accessibilità non coperti dagli strumenti integrati o per richiedere contenuti in formato alternativo, <a href="%s">contattaci tramite questa pagina</a>.',
				'contact_no_url'      => 'Per segnalare problemi di accessibilità o richiedere contenuti in formato alternativo, contattare il responsabile del sito.',
				'section_procedure'   => 'Procedura di attuazione',
				'procedure_text'      => "In caso di risposta insoddisfacente o assenza di risposta entro 30 giorni dalla segnalazione, è possibile contattare il Difensore Civico Digitale tramite il sito dell'Agenzia per l'Italia Digitale (AgID) all'indirizzo",
				'procedure_link_url'  => 'https://www.agid.gov.it/it/form/difensore-civico-digitale',
				'procedure_link_label'=> 'agid.gov.it',
				'section_info'        => 'Informazioni sulla dichiarazione',
				'meta_eval'           => 'Metodo di valutazione',
				'meta_date'           => 'Data della dichiarazione',
				'meta_review'         => 'Data di revisione',
				'meta_org'            => 'Responsabile',
				'eval_auto'           => 'Autovalutazione tramite Google Lighthouse',
				'eval_third'          => 'Valutazione effettuata da terza parte',
				'eval_formal'         => 'Uso di un metodo di valutazione formale',
				'footer'              => 'Questa dichiarazione è stata redatta con MB Accessibility – MB Digital Innovation.',
			),
			'en' => array(
				'title'               => 'Accessibility Statement',
				'legal_ref'           => 'Prepared in accordance with the Web Accessibility Directive (EU) 2016/2102',
				'section_commitment'  => 'Commitment to Accessibility',
				'commitment_text'     => '<strong>%1$s</strong> is committed to making its website <a href="%2$s">%2$s</a> accessible, in accordance with WCAG 2.1 Level AA guidelines and applicable regulations.',
				'section_status'      => 'Conformance Status',
				'evaluated_text'      => 'This website has been evaluated against the Web Content Accessibility Guidelines (WCAG) 2.1, Level AA.',
				'status_conforme'     => 'Fully conformant',
				'status_parzialmente' => 'Partially conformant',
				'status_non_conforme' => 'Non-conformant',
				'status_onere'        => 'Partially conformant – with disproportionate burden',
				'section_issues'      => 'Non-accessible Content',
				'issues_intro'        => 'The following WCAG criteria are not currently fully met:',
				'section_burden'      => 'Disproportionate Burden',
				'section_widget'      => 'Compensatory Measures – Accessibility Widget',
				'widget_intro'        => 'This website integrates an accessibility widget that provides users with tools to customise their browsing experience and compensate for certain content limitations. The active features mitigate the following WCAG criteria:',
				'th_criterion'        => 'Criterion',
				'th_description'      => 'Description',
				'th_tool'             => 'Tool provided',
				'section_contact'     => 'Feedback and Alternative Content',
				'contact_with_url'    => 'To report accessibility issues not covered by the built-in tools or to request content in an alternative format, <a href="%s">contact us via this page</a>.',
				'contact_no_url'      => 'To report accessibility issues or request content in an alternative format, please contact the site administrator.',
				'section_procedure'   => 'Enforcement Procedure',
				'procedure_text'      => 'If you have not received a satisfactory response within 30 days, you may contact the relevant national supervisory authority for web accessibility.',
				'procedure_link_url'  => '',
				'procedure_link_label'=> '',
				'section_info'        => 'Declaration Information',
				'meta_eval'           => 'Evaluation method',
				'meta_date'           => 'Date of declaration',
				'meta_review'         => 'Date of review',
				'meta_org'            => 'Responsible party',
				'eval_auto'           => 'Self-evaluation using Google Lighthouse',
				'eval_third'          => 'Evaluation carried out by a third party',
				'eval_formal'         => 'Use of a formal evaluation method',
				'footer'              => 'This statement was prepared with MB Accessibility – MB Digital Innovation.',
			),
			'de' => array(
				'title'               => 'Barrierefreiheitserklärung',
				'legal_ref'           => 'Erstellt gemäß der Richtlinie (EU) 2016/2102 über den barrierefreien Zugang zu Websites und mobilen Anwendungen',
				'section_commitment'  => 'Verpflichtung zur Barrierefreiheit',
				'commitment_text'     => '<strong>%1$s</strong> verpflichtet sich, seine Website <a href="%2$s">%2$s</a> barrierefrei zugänglich zu machen, in Übereinstimmung mit den WCAG 2.1 Level AA Richtlinien und den geltenden Vorschriften.',
				'section_status'      => 'Konformitätsstatus',
				'evaluated_text'      => 'Diese Website wurde anhand der Richtlinien für barrierefreie Webinhalte (WCAG) 2.1, Konformitätsstufe AA bewertet.',
				'status_conforme'     => 'Vollständig konform',
				'status_parzialmente' => 'Teilweise konform',
				'status_non_conforme' => 'Nicht konform',
				'status_onere'        => 'Teilweise konform – mit unverhältnismäßiger Belastung',
				'section_issues'      => 'Nicht barrierefreie Inhalte',
				'issues_intro'        => 'Die folgenden WCAG-Kriterien werden derzeit nicht vollständig erfüllt:',
				'section_burden'      => 'Unverhältnismäßige Belastung',
				'section_widget'      => 'Kompensationsmaßnahmen – Barrierefreiheits-Widget',
				'widget_intro'        => 'Diese Website integriert ein Barrierefreiheits-Widget, das Nutzern Werkzeuge zur Anpassung des Surferlebnisses und zum Ausgleich bestimmter inhaltlicher Einschränkungen bietet. Die aktiven Funktionen mindern folgende WCAG-Kriterien:',
				'th_criterion'        => 'Kriterium',
				'th_description'      => 'Beschreibung',
				'th_tool'             => 'Bereitgestelltes Werkzeug',
				'section_contact'     => 'Rückmeldung und alternative Inhalte',
				'contact_with_url'    => 'Um Probleme mit der Barrierefreiheit zu melden oder Inhalte in einem alternativen Format anzufordern, <a href="%s">kontaktieren Sie uns über diese Seite</a>.',
				'contact_no_url'      => 'Um Probleme mit der Barrierefreiheit zu melden oder Inhalte in einem alternativen Format anzufordern, wenden Sie sich bitte an den Website-Administrator.',
				'section_procedure'   => 'Durchsetzungsverfahren',
				'procedure_text'      => 'Falls Sie innerhalb von 30 Tagen keine zufriedenstellende Antwort erhalten haben, können Sie sich an die zuständige nationale Aufsichtsbehörde für Web-Barrierefreiheit wenden.',
				'procedure_link_url'  => '',
				'procedure_link_label'=> '',
				'section_info'        => 'Informationen zur Erklärung',
				'meta_eval'           => 'Bewertungsmethode',
				'meta_date'           => 'Datum der Erklärung',
				'meta_review'         => 'Datum der Überprüfung',
				'meta_org'            => 'Verantwortliche Stelle',
				'eval_auto'           => 'Selbstbewertung mit Google Lighthouse',
				'eval_third'          => 'Bewertung durch eine dritte Partei',
				'eval_formal'         => 'Verwendung einer formalen Bewertungsmethode',
				'footer'              => 'Diese Erklärung wurde mit MB Accessibility – MB Digital Innovation erstellt.',
			),
			'fr' => array(
				'title'               => "Déclaration d'accessibilité",
				'legal_ref'           => "Rédigée conformément à la Directive (UE) 2016/2102 relative à l'accessibilité des sites web",
				'section_commitment'  => "Engagement en matière d'accessibilité",
				'commitment_text'     => '<strong>%1$s</strong> s\'engage à rendre son site web <a href="%2$s">%2$s</a> accessible, conformément aux directives WCAG 2.1 niveau AA et à la réglementation applicable.',
				'section_status'      => 'État de conformité',
				'evaluated_text'      => "Ce site web a été évalué par rapport aux Règles pour l'accessibilité des contenus Web (WCAG) 2.1, niveau AA.",
				'status_conforme'     => 'Entièrement conforme',
				'status_parzialmente' => 'Partiellement conforme',
				'status_non_conforme' => 'Non conforme',
				'status_onere'        => 'Partiellement conforme – avec charge disproportionnée',
				'section_issues'      => 'Contenus non accessibles',
				'issues_intro'        => 'Les critères WCAG suivants ne sont pas entièrement respectés à ce jour :',
				'section_burden'      => 'Charge disproportionnée',
				'section_widget'      => "Mesures compensatoires – Widget d'accessibilité",
				'widget_intro'        => "Ce site web intègre un widget d'accessibilité qui fournit aux utilisateurs des outils pour personnaliser leur expérience de navigation et compenser certaines limitations des contenus. Les fonctionnalités actives atténuent les critères WCAG suivants :",
				'th_criterion'        => 'Critère',
				'th_description'      => 'Description',
				'th_tool'             => 'Outil fourni',
				'section_contact'     => 'Retours et contenus alternatifs',
				'contact_with_url'    => "Pour signaler des problèmes d'accessibilité ou demander des contenus dans un format alternatif, <a href=\"%s\">contactez-nous via cette page</a>.",
				'contact_no_url'      => "Pour signaler des problèmes d'accessibilité ou demander des contenus dans un format alternatif, veuillez contacter l'administrateur du site.",
				'section_procedure'   => 'Procédure de mise en application',
				'procedure_text'      => "Si vous n'avez pas reçu de réponse satisfaisante dans un délai de 30 jours, vous pouvez contacter l'autorité nationale de surveillance compétente en matière d'accessibilité web.",
				'procedure_link_url'  => '',
				'procedure_link_label'=> '',
				'section_info'        => 'Informations sur la déclaration',
				'meta_eval'           => "Méthode d'évaluation",
				'meta_date'           => 'Date de la déclaration',
				'meta_review'         => 'Date de révision',
				'meta_org'            => 'Responsable',
				'eval_auto'           => 'Auto-évaluation via Google Lighthouse',
				'eval_third'          => 'Évaluation réalisée par un tiers',
				'eval_formal'         => "Utilisation d'une méthode d'évaluation formelle",
				'footer'              => 'Cette déclaration a été rédigée avec MB Accessibility – MB Digital Innovation.',
			),
			'ru' => array(
				'title'               => 'Заявление о доступности',
				'legal_ref'           => 'Составлено в соответствии с Директивой ЕС 2016/2102 о доступности веб-сайтов',
				'section_commitment'  => 'Обязательство по обеспечению доступности',
				'commitment_text'     => '<strong>%1$s</strong> обязуется обеспечить доступность своего веб-сайта <a href="%2$s">%2$s</a> в соответствии с руководящими принципами WCAG 2.1 уровня AA и применимым законодательством.',
				'section_status'      => 'Статус соответствия',
				'evaluated_text'      => 'Данный веб-сайт оценён на соответствие Руководству по обеспечению доступности веб-контента (WCAG) 2.1, уровень AA.',
				'status_conforme'     => 'Полностью соответствует',
				'status_parzialmente' => 'Частично соответствует',
				'status_non_conforme' => 'Не соответствует',
				'status_onere'        => 'Частично соответствует – с несоразмерной нагрузкой',
				'section_issues'      => 'Недоступное содержимое',
				'issues_intro'        => 'Следующие критерии WCAG в настоящее время не соблюдаются в полной мере:',
				'section_burden'      => 'Несоразмерная нагрузка',
				'section_widget'      => 'Компенсационные меры – Виджет доступности',
				'widget_intro'        => 'Этот веб-сайт включает виджет доступности, предоставляющий пользователям инструменты для настройки работы в браузере и компенсации отдельных ограничений контента. Активные функции смягчают следующие критерии WCAG:',
				'th_criterion'        => 'Критерий',
				'th_description'      => 'Описание',
				'th_tool'             => 'Предоставляемый инструмент',
				'section_contact'     => 'Обратная связь и альтернативный контент',
				'contact_with_url'    => 'Чтобы сообщить о проблемах с доступностью или запросить контент в альтернативном формате, <a href="%s">свяжитесь с нами через эту страницу</a>.',
				'contact_no_url'      => 'Чтобы сообщить о проблемах с доступностью или запросить контент в альтернативном формате, обратитесь к администратору сайта.',
				'section_procedure'   => 'Процедура обжалования',
				'procedure_text'      => 'Если в течение 30 дней вы не получили удовлетворительного ответа, вы можете обратиться в компетентный национальный орган надзора за доступностью веб-сайтов.',
				'procedure_link_url'  => '',
				'procedure_link_label'=> '',
				'section_info'        => 'Информация о заявлении',
				'meta_eval'           => 'Метод оценки',
				'meta_date'           => 'Дата составления заявления',
				'meta_review'         => 'Дата пересмотра',
				'meta_org'            => 'Ответственная сторона',
				'eval_auto'           => 'Самооценка с использованием Google Lighthouse',
				'eval_third'          => 'Оценка, проведённая третьей стороной',
				'eval_formal'         => 'Использование формального метода оценки',
				'footer'              => 'Это заявление подготовлено с помощью MB Accessibility – MB Digital Innovation.',
			),
		);
		return $all[ $lang ] ?? $all['it'];
	}

	private function get_mitigations_i18n( string $lang ): array {
		$all = array(
			'it' => array(
				array( 'criterion' => '1.4.3',         'name' => 'Contrasto (minimo)',           'tool' => 'Modalità alto contrasto e contrasto negativo' ),
				array( 'criterion' => '1.4.1',         'name' => 'Uso del colore',               'tool' => 'Profili per daltonismo (deuteranopia, protanopia, tritanopia)' ),
				array( 'criterion' => '1.4.4',         'name' => 'Ridimensionamento del testo',  'tool' => 'Regolazione incrementale della dimensione del testo' ),
				array( 'criterion' => '1.4.12',        'name' => 'Spaziatura del testo',         'tool' => 'Regolazione spaziatura tra lettere e parole' ),
				array( 'criterion' => '1.4.8',         'name' => 'Presentazione visiva',         'tool' => 'Font leggibile (Verdana), allineamento a sinistra, interlinea aumentata' ),
				array( 'criterion' => '2.3.3',         'name' => 'Animazione da interazioni',    'tool' => 'Pausa di animazioni e transizioni CSS' ),
				array( 'criterion' => '2.4.1',         'name' => 'Salto di blocchi',             'tool' => 'Skip link per la navigazione diretta al contenuto principale' ),
				array( 'criterion' => '2.4.11/2.4.13', 'name' => 'Aspetto del focus',            'tool' => 'Indicatore focus da tastiera potenziato con bordo visibile' ),
				array( 'criterion' => '2.5.3',         'name' => 'Etichette nel nome',           'tool' => 'Screen reader integrato con lettura vocale su clic o hover' ),
			),
			'en' => array(
				array( 'criterion' => '1.4.3',         'name' => 'Contrast (Minimum)',           'tool' => 'High contrast and negative contrast modes' ),
				array( 'criterion' => '1.4.1',         'name' => 'Use of Colour',                'tool' => 'Colour blindness profiles (deuteranopia, protanopia, tritanopia)' ),
				array( 'criterion' => '1.4.4',         'name' => 'Resize Text',                  'tool' => 'Incremental text size adjustment' ),
				array( 'criterion' => '1.4.12',        'name' => 'Text Spacing',                 'tool' => 'Letter and word spacing adjustment' ),
				array( 'criterion' => '1.4.8',         'name' => 'Visual Presentation',          'tool' => 'Readable font (Verdana), left alignment, increased line height' ),
				array( 'criterion' => '2.3.3',         'name' => 'Animation from Interactions',  'tool' => 'Pause of CSS animations and transitions' ),
				array( 'criterion' => '2.4.1',         'name' => 'Bypass Blocks',                'tool' => 'Skip link for direct navigation to main content' ),
				array( 'criterion' => '2.4.11/2.4.13', 'name' => 'Focus Appearance',             'tool' => 'Enhanced keyboard focus indicator with visible outline' ),
				array( 'criterion' => '2.5.3',         'name' => 'Label in Name',                'tool' => 'Integrated screen reader with voice reading on click or hover' ),
			),
			'de' => array(
				array( 'criterion' => '1.4.3',         'name' => 'Kontrast (Minimum)',            'tool' => 'Hochkontrast- und Negativkontrast-Modus' ),
				array( 'criterion' => '1.4.1',         'name' => 'Verwendung von Farbe',          'tool' => 'Farbenblindheitsprofile (Deuteranopie, Protanopie, Tritanopie)' ),
				array( 'criterion' => '1.4.4',         'name' => 'Textgröße ändern',              'tool' => 'Schrittweise Anpassung der Textgröße' ),
				array( 'criterion' => '1.4.12',        'name' => 'Textabstand',                   'tool' => 'Anpassung von Buchstaben- und Wortabstand' ),
				array( 'criterion' => '1.4.8',         'name' => 'Visuelle Darstellung',          'tool' => 'Lesbare Schriftart (Verdana), linksbündig, erhöhter Zeilenabstand' ),
				array( 'criterion' => '2.3.3',         'name' => 'Animation durch Interaktion',   'tool' => 'Pause von CSS-Animationen und Übergängen' ),
				array( 'criterion' => '2.4.1',         'name' => 'Blöcke überspringen',           'tool' => 'Skip-Link zur direkten Navigation zum Hauptinhalt' ),
				array( 'criterion' => '2.4.11/2.4.13', 'name' => 'Fokusdarstellung',              'tool' => 'Verbesserter Tastaturfokus-Indikator mit sichtbarem Rahmen' ),
				array( 'criterion' => '2.5.3',         'name' => 'Beschriftung im Namen',         'tool' => 'Integrierter Screenreader mit Sprachausgabe per Klick oder Hover' ),
			),
			'fr' => array(
				array( 'criterion' => '1.4.3',         'name' => 'Contraste (minimum)',           'tool' => 'Modes contraste élevé et contraste négatif' ),
				array( 'criterion' => '1.4.1',         'name' => 'Utilisation de la couleur',     'tool' => 'Profils daltonisme (deutéranopie, protanopie, tritanopie)' ),
				array( 'criterion' => '1.4.4',         'name' => 'Redimensionnement du texte',    'tool' => 'Ajustement incrémental de la taille du texte' ),
				array( 'criterion' => '1.4.12',        'name' => 'Espacement du texte',           'tool' => "Ajustement de l'espacement des lettres et des mots" ),
				array( 'criterion' => '1.4.8',         'name' => 'Présentation visuelle',         'tool' => 'Police lisible (Verdana), alignement à gauche, interlignage augmenté' ),
				array( 'criterion' => '2.3.3',         'name' => 'Animation suite à interaction', 'tool' => 'Pause des animations et transitions CSS' ),
				array( 'criterion' => '2.4.1',         'name' => 'Contournement de blocs',        'tool' => "Lien d'évitement pour naviguer directement au contenu principal" ),
				array( 'criterion' => '2.4.11/2.4.13', 'name' => 'Apparence du focus',            'tool' => 'Indicateur de focus clavier amélioré avec contour visible' ),
				array( 'criterion' => '2.5.3',         'name' => 'Étiquette dans le nom',         'tool' => "Lecteur d'écran intégré avec lecture vocale au clic ou survol" ),
			),
			'ru' => array(
				array( 'criterion' => '1.4.3',         'name' => 'Контрастность (минимум)',       'tool' => 'Режимы высокого и негативного контраста' ),
				array( 'criterion' => '1.4.1',         'name' => 'Использование цвета',           'tool' => 'Профили цветовой слепоты (дейтеранопия, протанопия, тританопия)' ),
				array( 'criterion' => '1.4.4',         'name' => 'Изменение размера текста',      'tool' => 'Поэтапная настройка размера текста' ),
				array( 'criterion' => '1.4.12',        'name' => 'Межбуквенный интервал',         'tool' => 'Настройка межбуквенного и межсловного интервала' ),
				array( 'criterion' => '1.4.8',         'name' => 'Визуальное представление',      'tool' => 'Читаемый шрифт (Verdana), выравнивание по левому краю, увеличенный межстрочный интервал' ),
				array( 'criterion' => '2.3.3',         'name' => 'Анимация при взаимодействии',   'tool' => 'Приостановка CSS-анимации и переходов' ),
				array( 'criterion' => '2.4.1',         'name' => 'Обход блоков',                  'tool' => 'Якорная ссылка для прямой навигации к основному содержимому' ),
				array( 'criterion' => '2.4.11/2.4.13', 'name' => 'Внешний вид фокуса',            'tool' => 'Улучшенный индикатор фокуса с видимым контуром' ),
				array( 'criterion' => '2.5.3',         'name' => 'Метка в имени',                 'tool' => 'Встроенный экранный диктор с голосовым чтением по клику или наведению' ),
			),
		);
		return $all[ $lang ] ?? $all['it'];
	}

	// -----------------------------------------------------------------------
	// Shortcode
	// -----------------------------------------------------------------------

	public function render_shortcode( $atts ): string {
		$s = MBA_Plugin::get_settings();

		// Determine display language
		$wpml_active  = ( '1' === ( $s['declaration_wpml'] ?? '0' ) ) && defined( 'ICL_SITEPRESS_VERSION' );
		$display_lang = 'it';
		if ( $wpml_active ) {
			$display_lang = apply_filters( 'wpml_current_language', null ) ?: 'it';
		}

		// Translated string table for this language
		$t = $this->get_strings( $display_lang );

		// Shared fields
		$org         = $s['declaration_org_name']    ?? '';
		$site_url    = esc_url( $s['declaration_site_url'] ?: home_url() );
		$status      = $s['declaration_status']      ?? 'parzialmente';
		$eval_method = $s['declaration_eval_method'] ?? 'autovalutazione';
		$date_decl   = $s['declaration_date']        ?? '';
		$date_review = $s['declaration_review_date'] ?? '';

		// Per-language variable fields
		if ( $wpml_active ) {
			$lang_data = $s['declaration_langs'][ $display_lang ] ?? null;
			if ( null !== $lang_data ) {
				$issues      = $lang_data['issues']      ?? '';
				$burden      = $lang_data['burden_text'] ?? '';
				$contact_url = esc_url( $lang_data['contact_url'] ?? '' );
			} else {
				$issues      = $s['declaration_issues']      ?? '';
				$burden      = $s['declaration_burden_text'] ?? '';
				$contact_url = esc_url( $s['declaration_contact_url'] ?? '' );
			}
		} else {
			$issues      = $s['declaration_issues']      ?? '';
			$burden      = $s['declaration_burden_text'] ?? '';
			$contact_url = esc_url( $s['declaration_contact_url'] ?? '' );
		}

		// Status badge
		$status_colors = array(
			'conforme'     => array( 'color' => '#1a6636', 'bg' => '#edfaf1', 'border' => '#6fcf97' ),
			'parzialmente' => array( 'color' => '#7a5400', 'bg' => '#fff8e6', 'border' => '#f4c543' ),
			'non_conforme' => array( 'color' => '#7a1a1a', 'bg' => '#fdf0f0', 'border' => '#e57373' ),
			'onere'        => array( 'color' => '#7a5400', 'bg' => '#fff8e6', 'border' => '#f4c543' ),
		);
		$status_labels = array(
			'conforme'     => $t['status_conforme'],
			'parzialmente' => $t['status_parzialmente'],
			'non_conforme' => $t['status_non_conforme'],
			'onere'        => $t['status_onere'],
		);
		$sc       = $status_colors[ $status ] ?? $status_colors['parzialmente'];
		$sc_label = $status_labels[ $status ] ?? $t['status_parzialmente'];

		// Evaluation method label
		$eval_map   = array(
			'autovalutazione' => $t['eval_auto'],
			'terza_parte'     => $t['eval_third'],
			'metodo_formale'  => $t['eval_formal'],
		);
		$eval_label = $eval_map[ $eval_method ] ?? $t['eval_auto'];

		// Non-accessible content list
		$issues_html = '';
		if ( in_array( $status, array( 'parzialmente', 'non_conforme', 'onere' ), true ) && ! empty( trim( $issues ) ) ) {
			$lines = array_filter( array_map( 'trim', explode( "\n", $issues ) ) );
			if ( $lines ) {
				$items = '';
				foreach ( $lines as $line ) {
					$items .= '<li>' . esc_html( $line ) . '</li>';
				}
				$issues_html = '<ul class="mba-decl-list">' . $items . '</ul>';
			}
		}

		// Mitigations table rows (translated)
		$mitigations      = $this->get_mitigations_i18n( $display_lang );
		$mitigations_html = '';
		foreach ( $mitigations as $m ) {
			$mitigations_html .= '<tr>'
				. '<td class="mba-decl-criterion">WCAG ' . esc_html( $m['criterion'] ) . '</td>'
				. '<td class="mba-decl-criterion-name">' . esc_html( $m['name'] ) . '</td>'
				. '<td>' . esc_html( $m['tool'] ) . '</td>'
				. '</tr>';
		}

		ob_start();
		?>
		<div class="mba-declaration">

		<style>
		.mba-declaration {
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
			font-size: 16px;
			line-height: 1.7;
			color: #222;
			max-width: 860px;
			margin: 0 auto;
			padding: clamp(16px, 4vw, 48px);
			box-sizing: border-box;
		}
		.mba-declaration h2 {
			font-size: 1.75em;
			font-weight: 700;
			margin: 0 0 0.25em;
			color: #111;
			border: none;
			padding: 0;
		}
		.mba-declaration .mba-decl-subtitle {
			color: #555;
			margin: 0 0 2em;
			font-size: 0.95em;
		}
		.mba-declaration .mba-decl-section {
			background: #fff;
			border: 1px solid #e4e4e4;
			border-radius: 8px;
			padding: 24px 28px;
			margin-bottom: 20px;
		}
		.mba-declaration .mba-decl-section h3 {
			font-size: 1em;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .06em;
			color: #1a6baa;
			margin: 0 0 14px;
			padding: 0 0 10px;
			border-bottom: 2px solid #e8f1f8;
		}
		.mba-declaration .mba-decl-section p { margin: 0 0 10px; }
		.mba-declaration .mba-decl-section p:last-child { margin-bottom: 0; }
		.mba-declaration .mba-decl-badge {
			display: inline-block;
			padding: 5px 14px;
			border-radius: 20px;
			font-weight: 600;
			font-size: 0.9em;
			border: 1px solid;
			margin-bottom: 10px;
		}
		.mba-declaration .mba-decl-list { margin: 10px 0 0; padding-left: 20px; }
		.mba-declaration .mba-decl-list li { margin-bottom: 6px; }
		.mba-declaration .mba-decl-plugin-box {
			background: #f0f6ff;
			border: 1px solid #c3d8f0;
			border-radius: 8px;
			padding: 24px 28px;
			margin-bottom: 20px;
		}
		.mba-declaration .mba-decl-plugin-box h3 {
			font-size: 1em;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .06em;
			color: #1a6baa;
			margin: 0 0 14px;
			padding: 0 0 10px;
			border-bottom: 2px solid #c3d8f0;
		}
		.mba-declaration .mba-decl-plugin-box p { margin: 0 0 14px; color: #333; }
		.mba-declaration table.mba-decl-table { width: 100%; border-collapse: collapse; font-size: 0.9em; }
		.mba-declaration table.mba-decl-table th {
			background: #1a6baa; color: #fff; text-align: left;
			padding: 8px 12px; font-weight: 600;
		}
		.mba-declaration table.mba-decl-table td {
			padding: 8px 12px; border-bottom: 1px solid #e4e4e4; vertical-align: top;
		}
		.mba-declaration table.mba-decl-table tr:last-child td { border-bottom: none; }
		.mba-declaration table.mba-decl-table tr:nth-child(even) td { background: #f7fafd; }
		.mba-declaration .mba-decl-criterion { white-space: nowrap; font-weight: 600; color: #1a6baa; width: 120px; }
		.mba-declaration .mba-decl-criterion-name { font-weight: 600; width: 220px; }
		.mba-declaration .mba-decl-meta {
			display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 4px;
		}
		@media (max-width: 600px) {
			.mba-declaration .mba-decl-meta { grid-template-columns: 1fr; }
			.mba-declaration table.mba-decl-table { font-size: 0.8em; }
			.mba-declaration .mba-decl-criterion, .mba-declaration .mba-decl-criterion-name { width: auto; }
		}
		.mba-declaration .mba-decl-meta-item { background: #f7f7f7; border-radius: 6px; padding: 12px 16px; }
		.mba-declaration .mba-decl-meta-item strong {
			display: block; font-size: 0.8em; text-transform: uppercase;
			letter-spacing: .05em; color: #888; margin-bottom: 4px;
		}
		.mba-declaration .mba-decl-footer {
			font-size: 0.82em; color: #888;
			border-top: 1px solid #e4e4e4; padding-top: 16px; margin-top: 8px;
		}
		</style>

			<h2><?php echo esc_html( $t['title'] ); ?></h2>
			<p class="mba-decl-subtitle"><?php echo esc_html( $t['legal_ref'] ); ?></p>

			<?php if ( $org ) : ?>
			<div class="mba-decl-section">
				<h3><?php echo esc_html( $t['section_commitment'] ); ?></h3>
				<p><?php printf( wp_kses_post( $t['commitment_text'] ), esc_html( $org ), $site_url ); ?></p>
			</div>
			<?php endif; ?>

			<div class="mba-decl-section">
				<h3><?php echo esc_html( $t['section_status'] ); ?></h3>
				<p>
					<span class="mba-decl-badge" style="color:<?php echo esc_attr( $sc['color'] ); ?>;background:<?php echo esc_attr( $sc['bg'] ); ?>;border-color:<?php echo esc_attr( $sc['border'] ); ?>;">
						<?php echo esc_html( $sc_label ); ?>
					</span>
				</p>
				<p><?php echo esc_html( $t['evaluated_text'] ); ?></p>
			</div>

			<?php if ( $issues_html ) : ?>
			<div class="mba-decl-section">
				<h3><?php echo esc_html( $t['section_issues'] ); ?></h3>
				<p><?php echo esc_html( $t['issues_intro'] ); ?></p>
				<?php echo wp_kses_post( $issues_html ); ?>
			</div>
			<?php endif; ?>

			<?php if ( 'onere' === $status && ! empty( $burden ) ) : ?>
			<div class="mba-decl-section">
				<h3><?php echo esc_html( $t['section_burden'] ); ?></h3>
				<p><?php echo esc_html( $burden ); ?></p>
			</div>
			<?php endif; ?>

			<div class="mba-decl-plugin-box">
				<h3><?php echo esc_html( $t['section_widget'] ); ?></h3>
				<p><?php echo esc_html( $t['widget_intro'] ); ?></p>
				<table class="mba-decl-table">
					<thead>
						<tr>
							<th><?php echo esc_html( $t['th_criterion'] ); ?></th>
							<th><?php echo esc_html( $t['th_description'] ); ?></th>
							<th><?php echo esc_html( $t['th_tool'] ); ?></th>
						</tr>
					</thead>
					<tbody><?php echo wp_kses_post( $mitigations_html ); ?></tbody>
				</table>
			</div>

			<div class="mba-decl-section">
				<h3><?php echo esc_html( $t['section_contact'] ); ?></h3>
				<p>
					<?php
					if ( $contact_url ) {
						printf( wp_kses_post( $t['contact_with_url'] ), $contact_url );
					} else {
						echo esc_html( $t['contact_no_url'] );
					}
					?>
				</p>
			</div>

			<div class="mba-decl-section">
				<h3><?php echo esc_html( $t['section_procedure'] ); ?></h3>
				<p>
					<?php echo esc_html( $t['procedure_text'] ); ?>
					<?php if ( ! empty( $t['procedure_link_url'] ) ) : ?>
					<a href="<?php echo esc_url( $t['procedure_link_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $t['procedure_link_label'] ); ?></a>.
					<?php endif; ?>
				</p>
			</div>

			<div class="mba-decl-section">
				<h3><?php echo esc_html( $t['section_info'] ); ?></h3>
				<div class="mba-decl-meta">
					<div class="mba-decl-meta-item">
						<strong><?php echo esc_html( $t['meta_eval'] ); ?></strong>
						<?php echo esc_html( $eval_label ); ?>
					</div>
					<?php if ( $date_decl ) : ?>
					<div class="mba-decl-meta-item">
						<strong><?php echo esc_html( $t['meta_date'] ); ?></strong>
						<?php echo esc_html( $date_decl ); ?>
					</div>
					<?php endif; ?>
					<?php if ( $date_review ) : ?>
					<div class="mba-decl-meta-item">
						<strong><?php echo esc_html( $t['meta_review'] ); ?></strong>
						<?php echo esc_html( $date_review ); ?>
					</div>
					<?php endif; ?>
					<?php if ( $org ) : ?>
					<div class="mba-decl-meta-item">
						<strong><?php echo esc_html( $t['meta_org'] ); ?></strong>
						<?php echo esc_html( $org ); ?>
					</div>
					<?php endif; ?>
				</div>
				<p class="mba-decl-footer"><?php echo esc_html( $t['footer'] ); ?></p>
			</div>

		</div><!-- .mba-declaration -->
		<?php
		return ob_get_clean();
	}

	// -----------------------------------------------------------------------
	// Admin action – create / update WP page
	// -----------------------------------------------------------------------

	public function handle_create_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai i permessi necessari per eseguire questa azione.', 'mb-accessibility' ) );
		}

		check_admin_referer( 'mba_create_declaration_page', 'mba_declaration_nonce' );

		$s           = MBA_Plugin::get_settings();
		$wpml_active = ( '1' === ( $s['declaration_wpml'] ?? '0' ) ) && defined( 'ICL_SITEPRESS_VERSION' );

		// phpcs:ignore WordPress.Security.NonceVerification
		$lang    = $wpml_active ? sanitize_key( $_POST['mba_lang'] ?? '' ) : '';
		$page_id = 0;

		if ( $wpml_active && $lang ) {
			$page_id = (int) ( $s['declaration_langs'][ $lang ]['page_id'] ?? 0 );
		} else {
			$page_id = (int) ( $s['declaration_page_id'] ?? 0 );
		}

		$default_lang = $wpml_active ? ( apply_filters( 'wpml_default_language', null ) ?: 'it' ) : 'it';
		$target_lang  = ( $wpml_active && $lang ) ? $lang : $default_lang;

		$page_titles = array(
			'it' => 'Dichiarazione di accessibilità',
			'en' => 'Accessibility Statement',
			'de' => 'Barrierefreiheitserklärung',
			'fr' => "Déclaration d'accessibilité",
			'ru' => 'Заявление о доступности',
		);
		$page_slugs = array(
			'it' => 'dichiarazione-di-accessibilita',
			'en' => 'accessibility-statement',
			'de' => 'barrierefreiheitserklaerung',
			'fr' => 'declaration-accessibilite',
			'ru' => 'zayavlenie-o-dostupnosti',
		);

		$post_title = $page_titles[ $target_lang ] ?? ( $page_titles['it'] );
		$post_slug  = $page_slugs[ $target_lang ]  ?? ( 'dichiarazione-' . $target_lang );

		$page_data = array(
			'post_title'   => $post_title,
			'post_content' => '[mba_dichiarazione]',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_name'    => $post_slug,
		);

		if ( $page_id && get_post_status( $page_id ) ) {
			$page_data['ID'] = $page_id;
			$result          = wp_update_post( $page_data, true );
		} else {
			$result = wp_insert_post( $page_data, true );
		}

		$redirect_args = array(
			'page'           => 'mb-accessibility',
			'mba_active_tab' => 'mba-tab-dichiarazione',
		);

		if ( is_wp_error( $result ) ) {
			$redirect_args['mba_decl'] = 'error';
		} else {
			$saved = get_option( 'mba_settings', array() );
			if ( ! is_array( $saved ) ) {
				$saved = array();
			}

			if ( $wpml_active && $lang ) {
				// Save page ID for this language
				if ( ! isset( $saved['declaration_langs'] ) || ! is_array( $saved['declaration_langs'] ) ) {
					$saved['declaration_langs'] = array();
				}
				if ( ! isset( $saved['declaration_langs'][ $lang ] ) ) {
					$saved['declaration_langs'][ $lang ] = array();
				}
				$saved['declaration_langs'][ $lang ]['page_id'] = $result;

				// Update statement URL only for the default language
				if ( $lang === $default_lang ) {
					$saved['accessibility_statement_url'] = get_permalink( $result );
				}
			} else {
				$saved['declaration_page_id']         = $result;
				$saved['accessibility_statement_url'] = get_permalink( $result );
			}

			update_option( 'mba_settings', $saved );

			$redirect_args['mba_decl']     = 'ok';
			$redirect_args['mba_decl_url'] = urlencode( get_permalink( $result ) );
		}

		wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'options-general.php' ) ) );
		exit;
	}
}
