<?php
/**
 * MB Accessibility – Accessibility Declaration.
 *
 * Registers the [mba_dichiarazione] shortcode and handles
 * the "Create / Update page" admin action.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MBA_Declaration {

	public function __construct() {
		add_shortcode( 'mba_dichiarazione', array( $this, 'render_shortcode' ) );
		add_action( 'admin_post_mba_create_declaration_page', array( $this, 'handle_create_page' ) );
	}

	// -----------------------------------------------------------------------
	// Criteri WCAG mitigati dal plugin (fissi, sempre mostrati)
	// -----------------------------------------------------------------------

	private function get_plugin_mitigations(): array {
		return array(
			array(
				'criterion' => '1.4.3',
				'name'      => __( 'Contrasto (minimo)', 'mb-accessibility' ),
				'tool'      => __( 'Modalità alto contrasto e contrasto negativo', 'mb-accessibility' ),
			),
			array(
				'criterion' => '1.4.1',
				'name'      => __( 'Uso del colore', 'mb-accessibility' ),
				'tool'      => __( 'Profili per daltonismo (deuteranopia, protanopia, tritanopia)', 'mb-accessibility' ),
			),
			array(
				'criterion' => '1.4.4',
				'name'      => __( 'Ridimensionamento del testo', 'mb-accessibility' ),
				'tool'      => __( 'Regolazione incrementale della dimensione del testo', 'mb-accessibility' ),
			),
			array(
				'criterion' => '1.4.12',
				'name'      => __( 'Spaziatura del testo', 'mb-accessibility' ),
				'tool'      => __( 'Regolazione spaziatura tra lettere e parole', 'mb-accessibility' ),
			),
			array(
				'criterion' => '1.4.8',
				'name'      => __( 'Presentazione visiva', 'mb-accessibility' ),
				'tool'      => __( 'Font leggibile (Verdana), allineamento a sinistra, interlinea aumentata', 'mb-accessibility' ),
			),
			array(
				'criterion' => '2.3.3',
				'name'      => __( 'Animazione da interazioni', 'mb-accessibility' ),
				'tool'      => __( 'Pausa di animazioni e transizioni CSS', 'mb-accessibility' ),
			),
			array(
				'criterion' => '2.4.1',
				'name'      => __( 'Salto di blocchi', 'mb-accessibility' ),
				'tool'      => __( 'Skip link per la navigazione diretta al contenuto principale', 'mb-accessibility' ),
			),
			array(
				'criterion' => '2.4.11 / 2.4.13',
				'name'      => __( 'Aspetto del focus', 'mb-accessibility' ),
				'tool'      => __( 'Indicatore focus da tastiera potenziato con bordo visibile', 'mb-accessibility' ),
			),
			array(
				'criterion' => '2.5.3',
				'name'      => __( 'Etichette nel nome', 'mb-accessibility' ),
				'tool'      => __( 'Screen reader integrato con lettura vocale su clic o hover', 'mb-accessibility' ),
			),
		);
	}

	// -----------------------------------------------------------------------
	// Shortcode
	// -----------------------------------------------------------------------

	public function render_shortcode( $atts ): string {
		$s = MBA_Plugin::get_settings();

		// Shared fields
		$org         = $s['declaration_org_name']    ?? '';
		$site_url    = esc_url( $s['declaration_site_url'] ?: home_url() );
		$status      = $s['declaration_status']      ?? 'parzialmente';
		$eval_method = $s['declaration_eval_method'] ?? 'autovalutazione';
		$date_decl   = $s['declaration_date']        ?? '';
		$date_review = $s['declaration_review_date'] ?? '';

		// Per-language fields: use WPML current language when enabled, flat fields otherwise
		$wpml_active = ( '1' === ( $s['declaration_wpml'] ?? '0' ) ) && defined( 'ICL_SITEPRESS_VERSION' );
		if ( $wpml_active ) {
			$current_lang = apply_filters( 'wpml_current_language', null ) ?: 'it';
			$lang_data    = $s['declaration_langs'][ $current_lang ] ?? null;
			if ( null !== $lang_data ) {
				// Language-specific data exists: use it
				$issues      = $lang_data['issues']      ?? '';
				$burden      = $lang_data['burden_text'] ?? '';
				$contact_url = esc_url( $lang_data['contact_url'] ?? '' );
			} else {
				// Not yet translated for this language: fall back to flat fields
				$issues      = $s['declaration_issues']      ?? '';
				$burden      = $s['declaration_burden_text'] ?? '';
				$contact_url = esc_url( $s['declaration_contact_url'] ?? '' );
			}
		} else {
			$issues      = $s['declaration_issues']      ?? '';
			$burden      = $s['declaration_burden_text'] ?? '';
			$contact_url = esc_url( $s['declaration_contact_url'] ?? '' );
		}

		// Status badge colour
		$status_config = array(
			'conforme'     => array(
				'label' => __( 'Pienamente conforme', 'mb-accessibility' ),
				'color' => '#1a6636',
				'bg'    => '#edfaf1',
				'border'=> '#6fcf97',
			),
			'parzialmente' => array(
				'label' => __( 'Parzialmente conforme', 'mb-accessibility' ),
				'color' => '#7a5400',
				'bg'    => '#fff8e6',
				'border'=> '#f4c543',
			),
			'non_conforme' => array(
				'label' => __( 'Non conforme', 'mb-accessibility' ),
				'color' => '#7a1a1a',
				'bg'    => '#fdf0f0',
				'border'=> '#e57373',
			),
			'onere'        => array(
				'label' => __( 'Parzialmente conforme – con onere sproporzionato', 'mb-accessibility' ),
				'color' => '#7a5400',
				'bg'    => '#fff8e6',
				'border'=> '#f4c543',
			),
		);
		$sc = $status_config[ $status ] ?? $status_config['parzialmente'];

		// Evaluation method label
		$eval_labels = array(
			'autovalutazione' => __( 'Autovalutazione tramite Google Lighthouse', 'mb-accessibility' ),
			'terza_parte'     => __( 'Valutazione effettuata da terza parte', 'mb-accessibility' ),
			'metodo_formale'  => __( 'Uso di un metodo di valutazione formale', 'mb-accessibility' ),
		);
		$eval_label = $eval_labels[ $eval_method ] ?? $eval_labels['autovalutazione'];

		// Build non-accessible content list
		$issues_html = '';
		if ( in_array( $status, array( 'parzialmente', 'non_conforme', 'onere' ), true ) && ! empty( trim( $issues ) ) ) {
			$lines = array_filter( array_map( 'trim', explode( "\n", $issues ) ) );
			if ( $lines ) {
				$items = '';
				foreach ( $lines as $line ) {
					$items .= '<li>' . esc_html( $line ) . '</li>';
				}
				$issues_html = '<ul class="mba-decl-list">' . $items . '</ul>';
			}
		}

		// Plugin mitigations table
		$mitigations     = $this->get_plugin_mitigations();
		$mitigations_html = '';
		foreach ( $mitigations as $m ) {
			$mitigations_html .= '<tr>'
				. '<td class="mba-decl-criterion">WCAG ' . esc_html( $m['criterion'] ) . '</td>'
				. '<td class="mba-decl-criterion-name">' . esc_html( $m['name'] ) . '</td>'
				. '<td>' . esc_html( $m['tool'] ) . '</td>'
				. '</tr>';
		}

		ob_start();
		?>
		<div class="mba-declaration">

		<style>
		.mba-declaration {
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
			font-size: 16px;
			line-height: 1.7;
			color: #222;
			max-width: 860px;
			margin: 0 auto;
			padding: clamp(16px, 4vw, 48px);
			box-sizing: border-box;
		}
		.mba-declaration h2 {
			font-size: 1.75em;
			font-weight: 700;
			margin: 0 0 0.25em;
			color: #111;
			border: none;
			padding: 0;
		}
		.mba-declaration .mba-decl-subtitle {
			color: #555;
			margin: 0 0 2em;
			font-size: 0.95em;
		}
		.mba-declaration .mba-decl-section {
			background: #fff;
			border: 1px solid #e4e4e4;
			border-radius: 8px;
			padding: 24px 28px;
			margin-bottom: 20px;
		}
		.mba-declaration .mba-decl-section h3 {
			font-size: 1em;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .06em;
			color: #1a6baa;
			margin: 0 0 14px;
			padding: 0 0 10px;
			border-bottom: 2px solid #e8f1f8;
		}
		.mba-declaration .mba-decl-section p {
			margin: 0 0 10px;
		}
		.mba-declaration .mba-decl-section p:last-child { margin-bottom: 0; }
		.mba-declaration .mba-decl-badge {
			display: inline-block;
			padding: 5px 14px;
			border-radius: 20px;
			font-weight: 600;
			font-size: 0.9em;
			border: 1px solid;
			margin-bottom: 10px;
		}
		.mba-declaration .mba-decl-list {
			margin: 10px 0 0;
			padding-left: 20px;
		}
		.mba-declaration .mba-decl-list li {
			margin-bottom: 6px;
		}
		.mba-declaration .mba-decl-plugin-box {
			background: #f0f6ff;
			border: 1px solid #c3d8f0;
			border-radius: 8px;
			padding: 24px 28px;
			margin-bottom: 20px;
		}
		.mba-declaration .mba-decl-plugin-box h3 {
			font-size: 1em;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .06em;
			color: #1a6baa;
			margin: 0 0 14px;
			padding: 0 0 10px;
			border-bottom: 2px solid #c3d8f0;
		}
		.mba-declaration .mba-decl-plugin-box p {
			margin: 0 0 14px;
			color: #333;
		}
		.mba-declaration table.mba-decl-table {
			width: 100%;
			border-collapse: collapse;
			font-size: 0.9em;
		}
		.mba-declaration table.mba-decl-table th {
			background: #1a6baa;
			color: #fff;
			text-align: left;
			padding: 8px 12px;
			font-weight: 600;
		}
		.mba-declaration table.mba-decl-table td {
			padding: 8px 12px;
			border-bottom: 1px solid #e4e4e4;
			vertical-align: top;
		}
		.mba-declaration table.mba-decl-table tr:last-child td {
			border-bottom: none;
		}
		.mba-declaration table.mba-decl-table tr:nth-child(even) td {
			background: #f7fafd;
		}
		.mba-declaration .mba-decl-criterion {
			white-space: nowrap;
			font-weight: 600;
			color: #1a6baa;
			width: 110px;
		}
		.mba-declaration .mba-decl-criterion-name {
			font-weight: 600;
			width: 220px;
		}
		.mba-declaration .mba-decl-meta {
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 12px;
			margin-top: 4px;
		}
		@media (max-width: 600px) {
			.mba-declaration .mba-decl-meta { grid-template-columns: 1fr; }
			.mba-declaration table.mba-decl-table { font-size: 0.8em; }
			.mba-declaration .mba-decl-criterion { width: auto; }
			.mba-declaration .mba-decl-criterion-name { width: auto; }
		}
		.mba-declaration .mba-decl-meta-item {
			background: #f7f7f7;
			border-radius: 6px;
			padding: 12px 16px;
		}
		.mba-declaration .mba-decl-meta-item strong {
			display: block;
			font-size: 0.8em;
			text-transform: uppercase;
			letter-spacing: .05em;
			color: #888;
			margin-bottom: 4px;
		}
		.mba-declaration .mba-decl-footer {
			font-size: 0.82em;
			color: #888;
			border-top: 1px solid #e4e4e4;
			padding-top: 16px;
			margin-top: 8px;
		}
		</style>

			<h2><?php esc_html_e( 'Dichiarazione di accessibilità', 'mb-accessibility' ); ?></h2>
			<p class="mba-decl-subtitle">
				<?php esc_html_e( 'Redatta ai sensi del D.Lgs. 10 agosto 2018, n. 106 (recepimento Direttiva UE 2016/2102)', 'mb-accessibility' ); ?>
			</p>

			<!-- IMPEGNO -->
			<?php if ( $org ) : ?>
			<div class="mba-decl-section">
				<h3><?php esc_html_e( 'Impegno per l\'accessibilità', 'mb-accessibility' ); ?></h3>
				<p>
					<?php
					printf(
						wp_kses_post( __( '<strong>%1$s</strong> si impegna a rendere il proprio sito web <a href="%2$s">%2$s</a> accessibile, in conformità con le Linee guida WCAG 2.1 livello AA e la normativa vigente.', 'mb-accessibility' ) ),
						esc_html( $org ),
						$site_url
					);
					?>
				</p>
			</div>
			<?php endif; ?>

			<!-- STATO DI CONFORMITÀ -->
			<div class="mba-decl-section">
				<h3><?php esc_html_e( 'Stato di conformità', 'mb-accessibility' ); ?></h3>
				<p>
					<span class="mba-decl-badge" style="color:<?php echo esc_attr( $sc['color'] ); ?>;background:<?php echo esc_attr( $sc['bg'] ); ?>;border-color:<?php echo esc_attr( $sc['border'] ); ?>;">
						<?php echo esc_html( $sc['label'] ); ?>
					</span>
				</p>
				<p>
					<?php esc_html_e( 'Il sito è stato valutato rispetto alle Linee guida per l\'accessibilità dei contenuti Web (WCAG) 2.1, livello AA.', 'mb-accessibility' ); ?>
				</p>
			</div>

			<!-- CONTENUTI NON ACCESSIBILI -->
			<?php if ( $issues_html ) : ?>
			<div class="mba-decl-section">
				<h3><?php esc_html_e( 'Contenuti non accessibili', 'mb-accessibility' ); ?></h3>
				<p><?php esc_html_e( 'I seguenti criteri WCAG non sono al momento pienamente soddisfatti:', 'mb-accessibility' ); ?></p>
				<?php echo wp_kses_post( $issues_html ); ?>
			</div>
			<?php endif; ?>

			<!-- ONERE SPROPORZIONATO -->
			<?php if ( $status === 'onere' && ! empty( $burden ) ) : ?>
			<div class="mba-decl-section">
				<h3><?php esc_html_e( 'Onere sproporzionato', 'mb-accessibility' ); ?></h3>
				<p><?php echo esc_html( $burden ); ?></p>
			</div>
			<?php endif; ?>

			<!-- STRUMENTI COMPENSATIVI DEL PLUGIN -->
			<div class="mba-decl-plugin-box">
				<h3><?php esc_html_e( 'Misure compensative adottate – Widget di accessibilità', 'mb-accessibility' ); ?></h3>
				<p>
					<?php esc_html_e( 'Il sito integra un widget di accessibilità che fornisce agli utenti strumenti per personalizzare l\'esperienza di navigazione e compensare alcune limitazioni presenti nei contenuti. Le funzionalità attive mitigano i seguenti criteri WCAG:', 'mb-accessibility' ); ?>
				</p>
				<table class="mba-decl-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Criterio', 'mb-accessibility' ); ?></th>
							<th><?php esc_html_e( 'Descrizione', 'mb-accessibility' ); ?></th>
							<th><?php esc_html_e( 'Strumento fornito', 'mb-accessibility' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php echo wp_kses_post( $mitigations_html ); ?>
					</tbody>
				</table>
			</div>

			<!-- ALTERNATIVE E CONTATTI -->
			<div class="mba-decl-section">
				<h3><?php esc_html_e( 'Segnalazioni e contenuti alternativi', 'mb-accessibility' ); ?></h3>
				<p>
					<?php
					if ( $contact_url ) {
						printf(
							wp_kses_post( __( 'Per segnalare problemi di accessibilità non coperti dagli strumenti integrati o per richiedere contenuti in formato alternativo, <a href="%s">contattaci tramite questa pagina</a>.', 'mb-accessibility' ) ),
							$contact_url
						);
					} else {
						esc_html_e( 'Per segnalare problemi di accessibilità o richiedere contenuti in formato alternativo, contattare il responsabile del sito.', 'mb-accessibility' );
					}
					?>
				</p>
			</div>

			<!-- PROCEDURA DI RICORSO -->
			<div class="mba-decl-section">
				<h3><?php esc_html_e( 'Procedura di attuazione', 'mb-accessibility' ); ?></h3>
				<p>
					<?php esc_html_e( 'In caso di risposta insoddisfacente o assenza di risposta entro 30 giorni dalla segnalazione, è possibile contattare il Difensore Civico Digitale tramite il sito dell\'Agenzia per l\'Italia Digitale (AgID) all\'indirizzo', 'mb-accessibility' ); ?>
					<a href="https://www.agid.gov.it/it/form/difensore-civico-digitale" target="_blank" rel="noopener">agid.gov.it</a>.
				</p>
			</div>

			<!-- INFORMAZIONI SULLA DICHIARAZIONE -->
			<div class="mba-decl-section">
				<h3><?php esc_html_e( 'Informazioni sulla dichiarazione', 'mb-accessibility' ); ?></h3>
				<div class="mba-decl-meta">
					<div class="mba-decl-meta-item">
						<strong><?php esc_html_e( 'Metodo di valutazione', 'mb-accessibility' ); ?></strong>
						<?php echo esc_html( $eval_label ); ?>
					</div>
					<?php if ( $date_decl ) : ?>
					<div class="mba-decl-meta-item">
						<strong><?php esc_html_e( 'Data della dichiarazione', 'mb-accessibility' ); ?></strong>
						<?php echo esc_html( $date_decl ); ?>
					</div>
					<?php endif; ?>
					<?php if ( $date_review ) : ?>
					<div class="mba-decl-meta-item">
						<strong><?php esc_html_e( 'Data di revisione', 'mb-accessibility' ); ?></strong>
						<?php echo esc_html( $date_review ); ?>
					</div>
					<?php endif; ?>
					<?php if ( $org ) : ?>
					<div class="mba-decl-meta-item">
						<strong><?php esc_html_e( 'Responsabile', 'mb-accessibility' ); ?></strong>
						<?php echo esc_html( $org ); ?>
					</div>
					<?php endif; ?>
				</div>
				<p class="mba-decl-footer">
					<?php esc_html_e( 'Questa dichiarazione è stata redatta con MB Accessibility – MB Digital Innovation.', 'mb-accessibility' ); ?>
				</p>
			</div>

		</div><!-- .mba-declaration -->
		<?php
		return ob_get_clean();
	}

	// -----------------------------------------------------------------------
	// Admin action – create / update WP page
	// -----------------------------------------------------------------------

	public function handle_create_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai i permessi necessari per eseguire questa azione.', 'mb-accessibility' ) );
		}

		check_admin_referer( 'mba_create_declaration_page', 'mba_declaration_nonce' );

		$s           = MBA_Plugin::get_settings();
		$wpml_active = ( '1' === ( $s['declaration_wpml'] ?? '0' ) ) && defined( 'ICL_SITEPRESS_VERSION' );

		// Determine language and page ID to update
		// phpcs:ignore WordPress.Security.NonceVerification
		$lang    = $wpml_active ? sanitize_key( $_POST['mba_lang'] ?? '' ) : '';
		$page_id = 0;

		if ( $wpml_active && $lang ) {
			$page_id = (int) ( $s['declaration_langs'][ $lang ]['page_id'] ?? 0 );
		} else {
			$page_id = ! empty( $s['declaration_page_id'] ) ? (int) $s['declaration_page_id'] : 0;
		}

		// Page slug: append language suffix for non-default languages
		$default_lang = $wpml_active ? ( apply_filters( 'wpml_default_language', null ) ?: 'it' ) : 'it';
		$slug         = ( $wpml_active && $lang && $lang !== $default_lang )
			? 'dichiarazione-di-accessibilita-' . $lang
			: 'dichiarazione-di-accessibilita';

		$page_data = array(
			'post_title'   => __( 'Dichiarazione di accessibilità', 'mb-accessibility' ),
			'post_content' => '[mba_dichiarazione]',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_name'    => $slug,
		);

		if ( $page_id && get_post_status( $page_id ) ) {
			$page_data['ID'] = $page_id;
			$result          = wp_update_post( $page_data, true );
		} else {
			$result = wp_insert_post( $page_data, true );
		}

		$redirect_args = array(
			'page'           => 'mb-accessibility',
			'mba_active_tab' => 'mba-tab-dichiarazione',
		);
		if ( $wpml_active && $lang ) {
			$redirect_args['mba_lang'] = $lang;
		}

		if ( is_wp_error( $result ) ) {
			$redirect_args['mba_decl'] = 'error';
		} else {
			$saved = get_option( 'mba_settings', array() );
			if ( ! is_array( $saved ) ) {
				$saved = array();
			}

			if ( $wpml_active && $lang ) {
				// Save per-language page ID
				if ( ! isset( $saved['declaration_langs'] ) || ! is_array( $saved['declaration_langs'] ) ) {
					$saved['declaration_langs'] = array();
				}
				if ( ! isset( $saved['declaration_langs'][ $lang ] ) ) {
					$saved['declaration_langs'][ $lang ] = array();
				}
				$saved['declaration_langs'][ $lang ]['page_id'] = $result;

				// Register page language with WPML so pages are linked as translations
				$trid = null;
				if ( $lang !== $default_lang ) {
					$default_page_id = (int) ( $saved['declaration_langs'][ $default_lang ]['page_id'] ?? 0 );
					if ( $default_page_id ) {
						$trid = apply_filters( 'wpml_element_trid', null, $default_page_id, 'post_page' );
					}
				}
				do_action( 'wpml_set_element_language_details', array(
					'element_id'           => $result,
					'element_type'         => 'post_page',
					'trid'                 => $trid,
					'language_code'        => $lang,
					'source_language_code' => ( $lang !== $default_lang ) ? $default_lang : null,
				) );
			} else {
				$saved['declaration_page_id'] = $result;
			}

			// Always update the statement URL (used in widget footer) to the latest created page
			$saved['accessibility_statement_url'] = get_permalink( $result );
			update_option( 'mba_settings', $saved );

			$redirect_args['mba_decl']     = 'ok';
			$redirect_args['mba_decl_url'] = urlencode( get_permalink( $result ) );
		}

		wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'options-general.php' ) ) );
		exit;
	}
}
