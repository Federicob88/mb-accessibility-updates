<?php
/**
 * MB Accessibility – Admin settings page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MBA_Admin {

	public function __construct() {
		add_action( 'admin_menu',                              array( $this, 'add_menu' ) );
		add_action( 'admin_init',                              array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts',                   array( $this, 'enqueue_scripts' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( MBA_FILE ), array( $this, 'plugin_action_links' ) );
		add_action( 'admin_post_mba_check_updates',            array( $this, 'handle_check_updates' ) );
	}

	// -----------------------------------------------------------------------
	// Menu
	// -----------------------------------------------------------------------

	public function add_menu(): void {
		add_options_page(
			__( 'MB Accessibility', 'mb-accessibility' ),
			__( 'MB Accessibility', 'mb-accessibility' ),
			'manage_options',
			'mb-accessibility',
			array( $this, 'render_page' )
		);
	}

	// -----------------------------------------------------------------------
	// Settings registration
	// -----------------------------------------------------------------------

	public function register_settings(): void {
		register_setting(
			'mba_settings_group',
			'mba_settings',
			array( $this, 'sanitize' )
		);
	}

	public function sanitize( $input ): array {
		if ( ! is_array( $input ) ) {
			$input = array();
		}

		// -----------------------------------------------------------------------
		// Multi-form guard: the Declaration tab uses a separate <form> that only
		// posts declaration fields.  Without this guard, all other saved values
		// (license key, widget settings, …) would be wiped on every declaration
		// save because they are absent from $input.
		//
		// Strategy: identify which form was submitted via a hidden field
		// 'mba_form_id'.  If it is the declaration form, load the already-saved
		// option and only overwrite the declaration keys; return early.
		// -----------------------------------------------------------------------
		$form_id  = sanitize_key( $input['mba_form_id'] ?? 'main' );
		$existing = get_option( 'mba_settings', array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}
		$defaults = MBA_Plugin::get_default_settings();
		// Merge so we always have a complete base to work from.
		$existing = wp_parse_args( $existing, $defaults );

		if ( 'declaration' === $form_id ) {
			// Only sanitize/update the declaration fields; keep everything else.
			$clean = $existing;

			// WPML toggle (checkbox with hidden '0' before it)
			$clean['declaration_wpml'] = ( isset( $input['declaration_wpml'] ) && '1' === $input['declaration_wpml'] ) ? '1' : '0';

			// --- Shared fields (same for all languages) ---
			$clean['declaration_org_name']    = sanitize_text_field( $input['declaration_org_name']    ?? '' );
			$clean['declaration_site_url']    = esc_url_raw( $input['declaration_site_url']            ?? '' );
			$allowed_statuses                 = array( 'conforme', 'parzialmente', 'non_conforme', 'onere' );
			$clean['declaration_status']      = in_array( $input['declaration_status'] ?? '', $allowed_statuses, true )
				? $input['declaration_status'] : 'parzialmente';
			$allowed_evals                    = array( 'autovalutazione', 'terza_parte', 'metodo_formale' );
			$clean['declaration_eval_method'] = in_array( $input['declaration_eval_method'] ?? '', $allowed_evals, true )
				? $input['declaration_eval_method'] : 'autovalutazione';
			$clean['declaration_date']        = sanitize_text_field( $input['declaration_date']        ?? '' );
			$clean['declaration_review_date'] = sanitize_text_field( $input['declaration_review_date'] ?? '' );

			if ( '1' === $clean['declaration_wpml'] ) {
				// --- Per-language fields ---
				$lang = sanitize_key( $input['declaration_lang_code'] ?? 'it' );
				if ( ! isset( $clean['declaration_langs'] ) || ! is_array( $clean['declaration_langs'] ) ) {
					$clean['declaration_langs'] = array();
				}
				// Preserve existing page_id for this language if not re-submitted
				$prev_page_id = (int) ( $clean['declaration_langs'][ $lang ]['page_id'] ?? 0 );
				$clean['declaration_langs'][ $lang ] = array(
					'issues'      => sanitize_textarea_field( $input['declaration_lang_issues']  ?? '' ),
					'burden_text' => sanitize_textarea_field( $input['declaration_lang_burden']  ?? '' ),
					'contact_url' => esc_url_raw( $input['declaration_lang_contact']             ?? '' ),
					'page_id'     => (int) ( $input['declaration_lang_page_id'] ?? $prev_page_id ),
				);
			} else {
				// --- Single-language: flat fields (backward compat) ---
				$clean['declaration_issues']      = sanitize_textarea_field( $input['declaration_issues']      ?? '' );
				$clean['declaration_burden_text'] = sanitize_textarea_field( $input['declaration_burden_text'] ?? '' );
				$clean['declaration_contact_url'] = esc_url_raw( $input['declaration_contact_url']             ?? '' );
				$clean['declaration_page_id']     = (int) ( $input['declaration_page_id'] ?? $existing['declaration_page_id'] );
			}

			return $clean;
		}

		// --- Full sanitisation for the main settings form ---
		$clean = array();
		// (mba_form_id is a routing hint only – never stored)

		// License key – store as-is, validation happens at runtime
		$clean['license_key'] = sanitize_text_field( $input['license_key'] ?? '' );

		// Widget
		$clean['position']        = in_array( $input['position'] ?? '', array( 'left', 'right' ), true ) ? $input['position'] : 'right';
		$clean['position_mobile'] = in_array( $input['position_mobile'] ?? '', array( 'left', 'right' ), true ) ? $input['position_mobile'] : 'right';
		$clean['color']           = sanitize_hex_color( $input['color'] ?? '' ) ?: '#1a6baa';
		$clean['show_on_mobile']  = isset( $input['show_on_mobile'] ) ? '1' : '0';

		// Navigation
		$clean['skip_to_content']             = isset( $input['skip_to_content'] ) ? '1' : '0';
		$clean['skip_to_content_target']      = sanitize_html_class( $input['skip_to_content_target'] ?? 'content' ) ?: 'content';
		$clean['accessibility_statement_url'] = esc_url_raw( $input['accessibility_statement_url'] ?? '' );

		// Screen reader
		$clean['screen_reader_enabled'] = isset( $input['screen_reader_enabled'] ) ? '1' : '0';
		$clean['screen_reader_mode']    = in_array( $input['screen_reader_mode'] ?? '', array( 'click', 'hover' ), true )
			? $input['screen_reader_mode'] : 'click';

		// Feature toggles (v1 + v2)
		$features = array(
			'font_size', 'high_contrast', 'grayscale', 'invert',
			'readable_font', 'underline_links', 'pause_animations',
			'hide_images', 'line_height',
			// v2.0
			'colorblind', 'letter_spacing', 'text_left',
			'focus_indicator', 'reading_guide', 'big_cursor',
		);
		foreach ( $features as $f ) {
			$clean[ 'features_' . $f ] = isset( $input[ 'features_' . $f ] ) ? '1' : '0';
		}

		// Widget toggle icon URL
		$clean['toggle_icon_url']    = esc_url_raw( $input['toggle_icon_url'] ?? '' );
		$allowed_presets             = array( 'arancione', 'rosso', 'rosa', 'blu', 'verde' );
		$preset                      = sanitize_key( $input['toggle_icon_preset'] ?? 'arancione' );
		$clean['toggle_icon_preset'] = in_array( $preset, $allowed_presets, true ) ? $preset : 'arancione';

		// Reading guide height: only allow the whitelisted values
		$allowed_heights             = array( '10', '16', '22', '32', '44' );
		$clean['reading_guide_height'] = in_array( $input['reading_guide_height'] ?? '', $allowed_heights, true )
			? $input['reading_guide_height']
			: '22';

		// Declaration
		$clean['declaration_org_name']    = sanitize_text_field( $input['declaration_org_name']  ?? '' );
		$clean['declaration_site_url']    = esc_url_raw( $input['declaration_site_url']          ?? '' );
		$allowed_statuses                 = array( 'conforme', 'parzialmente', 'non_conforme', 'onere' );
		$clean['declaration_status']      = in_array( $input['declaration_status'] ?? '', $allowed_statuses, true )
			? $input['declaration_status'] : 'parzialmente';
		$clean['declaration_issues']      = sanitize_textarea_field( $input['declaration_issues']     ?? '' );
		$clean['declaration_burden_text'] = sanitize_textarea_field( $input['declaration_burden_text'] ?? '' );
		$clean['declaration_contact_url'] = esc_url_raw( $input['declaration_contact_url']            ?? '' );
		$allowed_evals                    = array( 'autovalutazione', 'terza_parte', 'metodo_formale' );
		$clean['declaration_eval_method'] = in_array( $input['declaration_eval_method'] ?? '', $allowed_evals, true )
			? $input['declaration_eval_method'] : 'autovalutazione';
		$clean['declaration_date']        = sanitize_text_field( $input['declaration_date']        ?? '' );
		$clean['declaration_review_date'] = sanitize_text_field( $input['declaration_review_date'] ?? '' );
		$clean['declaration_page_id']     = (int) ( $input['declaration_page_id'] ?? 0 );

		return $clean;
	}

	// -----------------------------------------------------------------------
	// Scripts / styles (admin page only)
	// -----------------------------------------------------------------------

	public function enqueue_scripts( string $hook ): void {
		if ( 'settings_page_mb-accessibility' !== $hook ) {
			return;
		}
		// Color picker
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		// Media uploader (for custom toggle icon)
		wp_enqueue_media();

		// Inline JS: tab system + colour picker init + media uploader logic
		wp_add_inline_script( 'wp-color-picker', '
jQuery(function($){

	// ---- Colour picker ----
	$(".mba-color-picker").wpColorPicker();

	// ---- Tab system ----
	var STORAGE_KEY = "mba_active_tab";
	var $tabs    = $(".mba-nav-tab");
	var $panels  = $(".mba-tab-panel");

	function activateTab( tabId ) {
		$tabs.removeClass("nav-tab-active").filter("[data-tab=\'" + tabId + "\']").addClass("nav-tab-active");
		$panels.addClass("mba-tab-hidden").filter("#" + tabId).removeClass("mba-tab-hidden");
		// Show submit only for settings tabs, not updates or declaration
		var noSubmitTabs = ["mba-tab-aggiornamenti", "mba-tab-dichiarazione"];
		if ( noSubmitTabs.indexOf( tabId ) !== -1 ) {
			$(".mba-tab-submit").addClass("mba-tab-hidden");
		} else {
			$(".mba-tab-submit").removeClass("mba-tab-hidden");
		}
		try { localStorage.setItem( STORAGE_KEY, tabId ); } catch(e){}
	}

	$tabs.on("click", function(e){
		e.preventDefault();
		activateTab( $(this).data("tab") );
	});

	// Restore last active tab — priority: URL query param > hash > localStorage > default
	var stored = "";
	try { stored = localStorage.getItem( STORAGE_KEY ) || ""; } catch(e){}
	var hash   = window.location.hash ? window.location.hash.replace("#","") : "";
	var urlTab = "";
	try { urlTab = new URLSearchParams( window.location.search ).get("mba_active_tab") || ""; } catch(e){}
	var initial = urlTab || hash || stored || "mba-tab-licenza";
	// Make sure the tab exists
	if ( !$("#" + initial).length ) { initial = "mba-tab-licenza"; }
	activateTab( initial );

	// ---- Media uploader for toggle icon ----
	var mediaUploader;

	$(document).on("click", "#mba-icon-upload-btn", function(e){
		e.preventDefault();
		if ( mediaUploader ) { mediaUploader.open(); return; }
		mediaUploader = wp.media({
			title:    "' . esc_js( __( 'Select Toggle Icon', 'mb-accessibility' ) ) . '",
			button:   { text: "' . esc_js( __( 'Use this image', 'mb-accessibility' ) ) . '" },
			multiple: false,
			library:  { type: ["image/png","image/jpeg","image/webp","image/gif","image/svg+xml"] }
		});
		mediaUploader.on("select", function(){
			var att = mediaUploader.state().get("selection").first().toJSON();
			$("#mba-toggle-icon-url").val( att.url );
			$("#mba-icon-preview").attr("src", att.url).css("display","block");
			$("#mba-icon-remove-btn").css("display","inline-block");
		});
		mediaUploader.open();
	});

	$(document).on("click", "#mba-icon-remove-btn", function(e){
		e.preventDefault();
		$("#mba-toggle-icon-url").val("");
		$("#mba-icon-preview").css("display","none");
		$(this).css("display","none");
	});

	// Persist active tab on form submit
	$("form#mba-settings-form").on("submit", function(){
		var active = $(".mba-nav-tab.nav-tab-active").data("tab") || "mba-tab-licenza";
		$(this).find("input[name=mba_active_tab]").val( active );
	});

	// Declaration: show/hide burden field based on status
	function mbaToggleBurden() {
		var val = $("#mba-declaration-status").val();
		if ( val === "onere" ) {
			$("#mba-burden-row").show();
		} else {
			$("#mba-burden-row").hide();
		}
		// Show issues field for non-conforme, parzialmente, onere
		if ( val === "conforme" ) {
			$("#mba-issues-row").hide();
		} else {
			$("#mba-issues-row").show();
		}
	}
	$("#mba-declaration-status").on("change", mbaToggleBurden);
	mbaToggleBurden();
});
		' );

		wp_add_inline_style( 'wp-color-picker', $this->admin_extra_css() );
	}

	private function admin_extra_css(): string {
		return '
			/* ---- Layout ---- */
			.mba-admin-wrap .form-table th { width: 260px; }
			.mba-admin-wrap .nav-tab-wrapper { margin-bottom: 0; }

			/* ---- Tab panels ---- */
			.mba-tab-panel {
				background: #fff;
				border: 1px solid #c3c4c7;
				border-top: none;
				padding: 24px 24px 8px;
				margin-bottom: 20px;
			}
			.mba-tab-hidden { display: none !important; }

			/* ---- Submit row ---- */
			.mba-tab-submit {
				padding: 0 0 20px;
			}

			/* ---- Section subheadings inside a panel ---- */
			.mba-section-heading {
				margin-top: 24px;
				margin-bottom: 0;
				padding-bottom: 6px;
				border-bottom: 2px solid #1a6baa;
				color: #1a6baa;
				font-size: 13px;
				font-weight: 600;
				text-transform: uppercase;
				letter-spacing: .05em;
			}
			.mba-section-heading:first-child { margin-top: 0; }

			.mba-badge {
				display: inline-block;
				background: #1a6baa;
				color: #fff;
				font-size: 10px;
				padding: 2px 6px;
				border-radius: 10px;
				vertical-align: middle;
				margin-left: 6px;
				font-weight: 600;
			}

			/* ---- License status banners ---- */
			.mba-license-ok, .mba-license-warn {
				display:flex; align-items:center; gap:10px;
				padding:10px 16px; border-radius:6px; margin-bottom:16px;
				font-size:13px; font-weight:500;
			}
			.mba-license-ok   { background:#edfaf1; border:1px solid #6fcf97; color:#1a6636; }
			.mba-license-warn { background:#fff8e6; border:1px solid #f4c543; color:#7a5400; }
			.mba-lic-dot { font-size:16px; line-height:1; }
			.mba-lic-dot--ok   { color:#27ae60; }
			.mba-lic-dot--warn { color:#e6a817; }

			/* ---- Icon preset selector ---- */
			.mba-icon-presets { display:flex; gap:14px; flex-wrap:wrap; margin-bottom:14px; }
			.mba-icon-preset-label { display:flex; flex-direction:column; align-items:center; gap:6px; cursor:pointer; }
			.mba-icon-preset-label input[type="radio"] { position:absolute; opacity:0; width:0; height:0; }
			.mba-icon-preset-thumb {
				width:60px; height:60px; border-radius:50%;
				object-fit:contain; background:#f0f0f0;
				border:3px solid transparent;
				padding:4px; transition:border-color .15s;
			}
			.mba-icon-preset-label input[type="radio"]:checked + .mba-icon-preset-thumb {
				border-color:#1a6baa;
				box-shadow: 0 0 0 2px #1a6baa33;
			}
			.mba-icon-preset-name { font-size:12px; color:#555; text-transform:capitalize; }

			/* ---- Icon uploader (custom) ---- */
			.mba-icon-wrap { display:flex; align-items:center; gap:14px; flex-wrap:wrap; }
			#mba-icon-preview {
				width:60px; height:60px;
				border-radius:50%;
				object-fit:contain;
				background:#f0f0f0;
				border:2px solid #ddd;
				padding:6px;
			}
			#mba-icon-upload-btn { flex-shrink:0; }
			#mba-icon-remove-btn { color:#c0392b; background:none; border:none; cursor:pointer; text-decoration:underline; font-size:13px; }
		';
	}

	// -----------------------------------------------------------------------
	// Plugin action links
	// -----------------------------------------------------------------------

	public function plugin_action_links( array $links ): array {
		$url = admin_url( 'options-general.php?page=mb-accessibility' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . __( 'Settings', 'mb-accessibility' ) . '</a>' );
		return $links;
	}

	// -----------------------------------------------------------------------
	// Settings page render
	// -----------------------------------------------------------------------

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = MBA_Plugin::get_settings();

		// Active tab after save: read hidden field from query string
		// phpcs:ignore WordPress.Security.NonceVerification
		$active_tab_after_save = isset( $_GET['mba_active_tab'] ) ? sanitize_key( $_GET['mba_active_tab'] ) : '';
		?>
		<div class="wrap mba-admin-wrap">

			<h1 style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="28" height="28" fill="#1a6baa" aria-hidden="true">
					<circle cx="50" cy="16" r="12"/>
					<path d="M78 34 C70 30 61 28 50 28 C39 28 30 30 22 34 L10 40 L15 52 L30 45 L30 62 L20 88 L33 88 L42 68 C44.5 69.5 47 70 50 70 C53 70 55.5 69.5 58 68 L67 88 L80 88 L70 62 L70 45 L85 52 L90 40 Z"/>
				</svg>
				<?php esc_html_e( 'MB Accessibility Settings', 'mb-accessibility' ); ?>
			</h1>

			<?php settings_errors( 'mba_settings_group' ); ?>

			<?php if ( $active_tab_after_save ) : ?>
			<script>
				try { localStorage.setItem( "mba_active_tab", "<?php echo esc_js( $active_tab_after_save ); ?>" ); } catch(e){}
			</script>
			<?php endif; ?>

			<!-- ============================================================
			     TAB NAVIGATION
			     ============================================================ -->
			<nav class="nav-tab-wrapper" aria-label="<?php esc_attr_e( 'Settings sections', 'mb-accessibility' ); ?>">
				<a href="#" class="nav-tab mba-nav-tab" data-tab="mba-tab-licenza">
					<?php esc_html_e( 'License', 'mb-accessibility' ); ?>
				</a>
				<a href="#" class="nav-tab mba-nav-tab" data-tab="mba-tab-widget">
					<?php esc_html_e( 'Widget', 'mb-accessibility' ); ?>
				</a>
				<a href="#" class="nav-tab mba-nav-tab" data-tab="mba-tab-navigazione">
					<?php esc_html_e( 'Navigation', 'mb-accessibility' ); ?>
				</a>
				<a href="#" class="nav-tab mba-nav-tab" data-tab="mba-tab-funzionalita">
					<?php esc_html_e( 'Features', 'mb-accessibility' ); ?>
				</a>
				<a href="#" class="nav-tab mba-nav-tab" data-tab="mba-tab-guida">
					<?php esc_html_e( 'Reading Guide', 'mb-accessibility' ); ?>
				</a>
				<a href="#" class="nav-tab mba-nav-tab" data-tab="mba-tab-dichiarazione">
					<?php esc_html_e( 'Declaration', 'mb-accessibility' ); ?>
				</a>
				<a href="#" class="nav-tab mba-nav-tab" data-tab="mba-tab-aggiornamenti">
					<?php esc_html_e( 'Updates', 'mb-accessibility' ); ?>
				</a>
			</nav>

			<!-- ============================================================
			     MAIN SETTINGS FORM  (wraps all tabs except Updates)
			     ============================================================ -->
			<form method="post" action="options.php" id="mba-settings-form">
				<?php settings_fields( 'mba_settings_group' ); ?>
				<input type="hidden" name="mba_settings[mba_form_id]" value="main">
				<input type="hidden" name="mba_active_tab" value="mba-tab-licenza">

				<!-- ==================== TAB: LICENZA ==================== -->
				<div id="mba-tab-licenza" class="mba-tab-panel">

					<?php
					$licensed = MBA_Plugin::is_licensed();
					$domain   = MBA_Plugin::get_domain();
					if ( $licensed ) : ?>
					<div class="mba-license-ok">
						<span class="mba-lic-dot mba-lic-dot--ok">&#10003;</span>
						<?php
						printf(
							/* translators: %s = domain */
							esc_html__( 'Plugin activated for %s', 'mb-accessibility' ),
							'<strong>' . esc_html( $domain ) . '</strong>'
						); ?>
					</div>
					<?php else : ?>
					<div class="mba-license-warn">
						<span class="mba-lic-dot mba-lic-dot--warn">&#9888;</span>
						<?php
						printf(
							/* translators: %s = domain */
							esc_html__( 'No valid license found for %s. The widget is not visible to visitors.', 'mb-accessibility' ),
							'<strong>' . esc_html( $domain ) . '</strong>'
						); ?>
					</div>
					<?php endif; ?>

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'License Key', 'mb-accessibility' ); ?></th>
							<td>
								<input type="text"
								       name="mba_settings[license_key]"
								       value="<?php echo esc_attr( $s['license_key'] ); ?>"
								       class="regular-text"
								       placeholder="XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX"
								       autocomplete="off"
								       spellcheck="false">
								<p class="description">
									<?php esc_html_e( 'Enter the license key provided by MB Digital Innovation for this domain.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
					</table>

				</div><!-- #mba-tab-licenza -->

				<!-- ==================== TAB: WIDGET ==================== -->
				<div id="mba-tab-widget" class="mba-tab-panel mba-tab-hidden">

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Panel Position (Desktop)', 'mb-accessibility' ); ?></th>
							<td>
								<select name="mba_settings[position]">
									<option value="right" <?php selected( $s['position'], 'right' ); ?>><?php esc_html_e( 'Right', 'mb-accessibility' ); ?></option>
									<option value="left"  <?php selected( $s['position'], 'left' );  ?>><?php esc_html_e( 'Left', 'mb-accessibility' ); ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Panel Position (Mobile)', 'mb-accessibility' ); ?></th>
							<td>
								<select name="mba_settings[position_mobile]">
									<option value="right" <?php selected( $s['position_mobile'] ?? 'right', 'right' ); ?>><?php esc_html_e( 'Right', 'mb-accessibility' ); ?></option>
									<option value="left"  <?php selected( $s['position_mobile'] ?? 'right', 'left' );  ?>><?php esc_html_e( 'Left', 'mb-accessibility' ); ?></option>
								</select>
								<p class="description">
									<?php esc_html_e( 'Position of the toggle button on smartphones and tablets (viewport ≤ 480 px).', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Primary Color', 'mb-accessibility' ); ?></th>
							<td>
								<input type="text"
								       class="mba-color-picker"
								       name="mba_settings[color]"
								       value="<?php echo esc_attr( $s['color'] ); ?>">
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Show on Mobile', 'mb-accessibility' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="mba_settings[show_on_mobile]" value="1" <?php checked( $s['show_on_mobile'], '1' ); ?>>
									<?php esc_html_e( 'Display the widget on smartphones and tablets', 'mb-accessibility' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Toggle Button Icon', 'mb-accessibility' ); ?></th>
							<td>
								<?php
								$icon_url    = $s['toggle_icon_url']    ?? '';
								$icon_preset = $s['toggle_icon_preset'] ?? 'arancione';
								$presets     = array(
									'arancione' => __( 'Orange', 'mb-accessibility' ),
									'rosso'     => __( 'Red',    'mb-accessibility' ),
									'rosa'      => __( 'Pink',   'mb-accessibility' ),
									'blu'       => __( 'Blue',   'mb-accessibility' ),
									'verde'     => __( 'Green',  'mb-accessibility' ),
								);
								?>
								<p style="font-weight:600;margin-bottom:8px;">
									<?php esc_html_e( 'Choose a colour variant:', 'mb-accessibility' ); ?>
								</p>
								<div class="mba-icon-presets">
									<?php foreach ( $presets as $key => $label ) : ?>
									<label class="mba-icon-preset-label">
										<input type="radio"
										       name="mba_settings[toggle_icon_preset]"
										       value="<?php echo esc_attr( $key ); ?>"
										       <?php checked( $icon_preset, $key ); ?>>
										<img class="mba-icon-preset-thumb"
										     src="<?php echo esc_url( MBA_URL . 'assets/images/mba-icon-' . $key . '.webp' ); ?>"
										     alt="<?php echo esc_attr( $label ); ?>">
										<span class="mba-icon-preset-name"><?php echo esc_html( $label ); ?></span>
									</label>
									<?php endforeach; ?>
								</div>

								<p style="font-weight:600;margin:14px 0 8px;">
									<?php esc_html_e( 'Or upload a custom icon (overrides colour selection above):', 'mb-accessibility' ); ?>
								</p>
								<input type="hidden"
								       id="mba-toggle-icon-url"
								       name="mba_settings[toggle_icon_url]"
								       value="<?php echo esc_attr( $icon_url ); ?>">
								<div class="mba-icon-wrap">
									<?php if ( $icon_url ) : ?>
										<img id="mba-icon-preview" src="<?php echo esc_url( $icon_url ); ?>" alt="">
									<?php else : ?>
										<img id="mba-icon-preview" src="" alt="" style="display:none;">
									<?php endif; ?>
									<button type="button" id="mba-icon-upload-btn" class="button">
										<?php esc_html_e( 'Select image', 'mb-accessibility' ); ?>
									</button>
									<button type="button" id="mba-icon-remove-btn"
									        style="<?php echo $icon_url ? '' : 'display:none;'; ?>">
										<?php esc_html_e( 'Remove', 'mb-accessibility' ); ?>
									</button>
								</div>
								<p class="description">
									<?php esc_html_e( 'PNG, JPG or WebP. Displayed as a circle (60×60 px).', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
					</table>

				</div><!-- #mba-tab-widget -->

				<!-- ==================== TAB: NAVIGAZIONE ==================== -->
				<div id="mba-tab-navigazione" class="mba-tab-panel mba-tab-hidden">

					<h2 class="mba-section-heading"><?php esc_html_e( 'Skip Link', 'mb-accessibility' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( '"Skip to Content" Link', 'mb-accessibility' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="mba_settings[skip_to_content]" value="1" <?php checked( $s['skip_to_content'], '1' ); ?>>
									<?php esc_html_e( 'Add a hidden "Skip to content" link (visible on keyboard focus)', 'mb-accessibility' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Skip Target Element ID', 'mb-accessibility' ); ?></th>
							<td>
								<input type="text"
								       name="mba_settings[skip_to_content_target]"
								       value="<?php echo esc_attr( $s['skip_to_content_target'] ); ?>"
								       class="regular-text"
								       placeholder="content">
								<p class="description">
									<?php esc_html_e( 'HTML id of your main content element (e.g. "content", "main", "primary"). The plugin auto-detects it if the specified element is not found.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Accessibility Statement URL', 'mb-accessibility' ); ?></th>
							<td>
								<?php
								$stmt_url = $s['accessibility_statement_url'] ?? '';
								if ( $stmt_url ) : ?>
								<a href="<?php echo esc_url( $stmt_url ); ?>" target="_blank" rel="noopener">
									<?php echo esc_html( $stmt_url ); ?>
								</a>
								<?php else : ?>
								<em style="color:#888;"><?php esc_html_e( 'Not set yet.', 'mb-accessibility' ); ?></em>
								<?php endif; ?>
								<!-- Hidden: preserve value on save without user input -->
								<input type="hidden"
								       name="mba_settings[accessibility_statement_url]"
								       value="<?php echo esc_attr( $stmt_url ); ?>">
								<p class="description">
									<?php esc_html_e( 'Populated automatically when you create or update the declaration page from the Declaration tab. Displayed as a link in the widget footer.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
					</table>

					<h2 class="mba-section-heading">
						<?php esc_html_e( 'Screen Reader', 'mb-accessibility' ); ?>
						<span class="mba-badge">Web Speech API</span>
					</h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Enable Screen Reader', 'mb-accessibility' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="mba_settings[screen_reader_enabled]" value="1" <?php checked( $s['screen_reader_enabled'], '1' ); ?>>
									<?php esc_html_e( 'Show the TTS screen reader button in the widget', 'mb-accessibility' ); ?>
								</label>
								<p class="description">
									<?php esc_html_e( 'Uses the browser\'s built-in Web Speech API. No external service required. Works in Chrome, Edge, Safari and most modern browsers.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Reading Mode', 'mb-accessibility' ); ?></th>
							<td>
								<select name="mba_settings[screen_reader_mode]">
									<option value="click" <?php selected( $s['screen_reader_mode'], 'click' ); ?>><?php esc_html_e( 'Click to Read – user clicks on text to hear it', 'mb-accessibility' ); ?></option>
									<option value="hover" <?php selected( $s['screen_reader_mode'], 'hover' ); ?>><?php esc_html_e( 'Hover to Read – text is read on mouse hover', 'mb-accessibility' ); ?></option>
								</select>
							</td>
						</tr>
					</table>

				</div><!-- #mba-tab-navigazione -->

				<!-- ==================== TAB: FUNZIONALITÀ ==================== -->
				<div id="mba-tab-funzionalita" class="mba-tab-panel mba-tab-hidden">

					<p style="margin-top:0;"><?php esc_html_e( 'Enable or disable individual features in the accessibility widget.', 'mb-accessibility' ); ?></p>
					<table class="form-table" role="presentation">
						<?php
						$feature_labels = array(
							// v1
							'font_size'        => __( 'Font Size Adjustment (increase / decrease text)', 'mb-accessibility' ),
							'high_contrast'    => __( 'High Contrast Mode', 'mb-accessibility' ),
							'grayscale'        => __( 'Grayscale Mode', 'mb-accessibility' ),
							'invert'           => __( 'Negative Contrast (inverted colours)', 'mb-accessibility' ),
							'readable_font'    => __( 'Readable Font (dyslexia-friendly, Verdana)', 'mb-accessibility' ),
							'underline_links'  => __( 'Force Underline on All Links', 'mb-accessibility' ),
							'pause_animations' => __( 'Pause Animations & Transitions', 'mb-accessibility' ),
							'hide_images'      => __( 'Hide Images', 'mb-accessibility' ),
							'line_height'      => __( 'Increased Line Height', 'mb-accessibility' ),
							// v2.0
							'colorblind'       => __( 'Color Blindness Profiles — Deuteranopia, Protanopia, Tritanopia (WCAG 1.4.1)', 'mb-accessibility' ),
							'letter_spacing'   => __( 'Text Spacing — letter & word spacing (WCAG 1.4.12)', 'mb-accessibility' ),
							'text_left'        => __( 'Left-align Text (helps dyslexia)', 'mb-accessibility' ),
							'focus_indicator'  => __( 'Enhanced Keyboard Focus Indicator (WCAG 2.4.11 / 2.4.13)', 'mb-accessibility' ),
							'reading_guide'    => __( 'Reading Guide — horizontal highlight following cursor/touch', 'mb-accessibility' ),
							'big_cursor'       => __( 'Large Cursor (desktop only, hidden on touch devices)', 'mb-accessibility' ),
						);
						foreach ( $feature_labels as $key => $label ) :
							$option_key = 'features_' . $key;
						?>
						<tr>
							<th scope="row"><?php echo esc_html( $label ); ?></th>
							<td>
								<input type="checkbox"
								       name="mba_settings[<?php echo esc_attr( $option_key ); ?>]"
								       value="1"
								       <?php checked( $s[ $option_key ], '1' ); ?>>
							</td>
						</tr>
						<?php endforeach; ?>
					</table>

				</div><!-- #mba-tab-funzionalita -->

				<!-- ==================== TAB: GUIDA LETTURA ==================== -->
				<div id="mba-tab-guida" class="mba-tab-panel mba-tab-hidden">

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Line Height', 'mb-accessibility' ); ?></th>
							<td>
								<select name="mba_settings[reading_guide_height]">
									<?php
									$heights = array(
										'10' => __( 'Very thin — 10 px (one line of small text)',  'mb-accessibility' ),
										'16' => __( 'Thin — 16 px (one line of normal text)',       'mb-accessibility' ),
										'22' => __( 'Standard — 22 px (default)',                   'mb-accessibility' ),
										'32' => __( 'Wide — 32 px (two lines)',                     'mb-accessibility' ),
										'44' => __( 'Extra wide — 44 px (three lines)',              'mb-accessibility' ),
									);
									foreach ( $heights as $val => $label ) :
									?>
									<option value="<?php echo esc_attr( $val ); ?>"
									        <?php selected( $s['reading_guide_height'] ?? '22', $val ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
									<?php endforeach; ?>
								</select>
								<p class="description">
									<?php esc_html_e( 'Height of the horizontal highlight bar that follows the cursor.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
					</table>

				</div><!-- #mba-tab-guida -->

				<!-- Submit button (hidden when Updates tab is active) -->
				<div class="mba-tab-submit">
					<?php submit_button( __( 'Save Settings', 'mb-accessibility' ) ); ?>
				</div>

			</form><!-- #mba-settings-form -->

			<!-- ==================== TAB: DICHIARAZIONE ==================== -->
			<!-- Outside the main form: has its own save form + page creation action -->
			<div id="mba-tab-dichiarazione" class="mba-tab-panel mba-tab-hidden">

				<?php
				// Success / error notices
				// phpcs:ignore WordPress.Security.NonceVerification
				$decl_status = isset( $_GET['mba_decl'] ) ? sanitize_key( $_GET['mba_decl'] ) : '';
				if ( $decl_status === 'ok' ) :
					// phpcs:ignore WordPress.Security.NonceVerification
					$decl_url = isset( $_GET['mba_decl_url'] ) ? esc_url( urldecode( sanitize_text_field( wp_unslash( $_GET['mba_decl_url'] ) ) ) ) : '';
				?>
				<div class="notice notice-success inline" style="margin:0 0 16px;">
					<p>
						<?php
						if ( $decl_url ) {
							printf(
								wp_kses_post( __( 'Pagina creata/aggiornata con successo. <a href="%s" target="_blank">Visualizza la dichiarazione →</a>', 'mb-accessibility' ) ),
								$decl_url
							);
						} else {
							esc_html_e( 'Pagina creata/aggiornata con successo.', 'mb-accessibility' );
						}
						?>
					</p>
				</div>
				<?php elseif ( $decl_status === 'error' ) : ?>
				<div class="notice notice-error inline" style="margin:0 0 16px;">
					<p><?php esc_html_e( 'Errore durante la creazione della pagina. Riprova.', 'mb-accessibility' ); ?></p>
				</div>
				<?php endif; ?>

				<?php
				// ---- WPML detection ----
				$wpml_detected     = defined( 'ICL_SITEPRESS_VERSION' );
				$wpml_enabled      = $wpml_detected && ( '1' === ( $s['declaration_wpml'] ?? '0' ) );
				$active_langs      = array();
				$default_lang      = 'it';
				$current_admin_lang = 'it';

				if ( $wpml_detected ) {
					$raw = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 0 ) );
					if ( is_array( $raw ) ) {
						foreach ( $raw as $lcode => $linfo ) {
							$active_langs[ $lcode ] = $linfo['native_name'] ?? strtoupper( $lcode );
						}
					}
					$default_lang       = apply_filters( 'wpml_default_language', null ) ?: 'it';
					// phpcs:ignore WordPress.Security.NonceVerification
					$current_admin_lang = isset( $_GET['mba_lang'] ) ? sanitize_key( $_GET['mba_lang'] ) : $default_lang;
					if ( ! isset( $active_langs[ $current_admin_lang ] ) ) {
						$current_admin_lang = $default_lang;
					}
				}

				// Per-language data for the currently selected admin language
				$lang_data = $s['declaration_langs'][ $current_admin_lang ] ?? array();
				?>

				<form method="post" action="options.php" id="mba-declaration-settings-form">
					<?php settings_fields( 'mba_settings_group' ); ?>
					<input type="hidden" name="mba_settings[mba_form_id]" value="declaration">
					<input type="hidden" name="mba_active_tab" value="mba-tab-dichiarazione">

					<?php if ( $wpml_detected ) : ?>
					<!-- WPML toggle -->
					<div style="background:#f0f6ff;border:1px solid #c3d8f0;border-radius:6px;padding:14px 18px;margin-bottom:20px;display:flex;align-items:flex-start;gap:12px;">
						<label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0;white-space:nowrap;font-weight:600;">
							<input type="hidden" name="mba_settings[declaration_wpml]" value="0">
							<input type="checkbox"
							       name="mba_settings[declaration_wpml]"
							       value="1"
							       id="mba-wpml-toggle"
							       <?php checked( $s['declaration_wpml'] ?? '0', '1' ); ?>>
							<?php esc_html_e( 'Modalità multilingua (WPML)', 'mb-accessibility' ); ?>
						</label>
						<span style="font-size:12px;color:#555;line-height:1.5;">
							<?php esc_html_e( 'Abilita per gestire criteri e contatti separatamente per ogni lingua. Salva dopo aver modificato questa opzione.', 'mb-accessibility' ); ?>
						</span>
					</div>
					<?php endif; ?>

					<?php if ( $wpml_enabled && count( $active_langs ) > 1 ) : ?>
					<!-- Language switcher -->
					<div style="margin-bottom:20px;">
						<strong style="display:block;margin-bottom:8px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#888;">
							<?php esc_html_e( 'Stai modificando:', 'mb-accessibility' ); ?>
						</strong>
						<div style="display:flex;gap:6px;flex-wrap:wrap;">
							<?php foreach ( $active_langs as $lcode => $lname ) :
								$lang_url = add_query_arg( array(
									'page'           => 'mb-accessibility',
									'mba_active_tab' => 'mba-tab-dichiarazione',
									'mba_lang'       => $lcode,
								), admin_url( 'options-general.php' ) );
								$is_active = ( $lcode === $current_admin_lang );
							?>
							<a href="<?php echo esc_url( $lang_url ); ?>"
							   style="display:inline-block;padding:5px 14px;border-radius:4px;font-size:13px;text-decoration:none;
							          font-weight:<?php echo $is_active ? '600' : '400'; ?>;
							          background:<?php echo $is_active ? '#1a6baa' : '#f0f0f0'; ?>;
							          color:<?php echo $is_active ? '#fff' : '#333'; ?>;
							          border:1px solid <?php echo $is_active ? '#1a6baa' : '#ccc'; ?>;">
								<?php echo esc_html( strtoupper( $lcode ) ); ?> – <?php echo esc_html( $lname ); ?>
							</a>
							<?php endforeach; ?>
						</div>
					</div>
					<input type="hidden" name="mba_settings[declaration_lang_code]"    value="<?php echo esc_attr( $current_admin_lang ); ?>">
					<input type="hidden" name="mba_settings[declaration_lang_page_id]" value="<?php echo esc_attr( $lang_data['page_id'] ?? 0 ); ?>">
					<?php endif; ?>

					<!-- ===== SHARED FIELDS ===== -->
					<?php if ( $wpml_enabled ) : ?>
					<h2 class="mba-section-heading" style="margin-top:0;"><?php esc_html_e( 'Dati condivisi (tutte le lingue)', 'mb-accessibility' ); ?></h2>
					<?php endif; ?>

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Nome organizzazione', 'mb-accessibility' ); ?></th>
							<td>
								<input type="text"
								       name="mba_settings[declaration_org_name]"
								       value="<?php echo esc_attr( $s['declaration_org_name'] ?? '' ); ?>"
								       class="regular-text"
								       placeholder="<?php esc_attr_e( 'Es. MB Digital Innovation', 'mb-accessibility' ); ?>">
								<p class="description">
									<?php esc_html_e( 'Nome dell\'ente o azienda responsabile del sito.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'URL del sito', 'mb-accessibility' ); ?></th>
							<td>
								<input type="url"
								       name="mba_settings[declaration_site_url]"
								       value="<?php echo esc_attr( $s['declaration_site_url'] ?? home_url() ); ?>"
								       class="regular-text"
								       placeholder="<?php echo esc_attr( home_url() ); ?>">
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Stato di conformità', 'mb-accessibility' ); ?></th>
							<td>
								<select name="mba_settings[declaration_status]" id="mba-declaration-status">
									<option value="conforme"     <?php selected( $s['declaration_status'] ?? 'parzialmente', 'conforme' ); ?>>
										<?php esc_html_e( 'Pienamente conforme', 'mb-accessibility' ); ?>
									</option>
									<option value="parzialmente" <?php selected( $s['declaration_status'] ?? 'parzialmente', 'parzialmente' ); ?>>
										<?php esc_html_e( 'Parzialmente conforme', 'mb-accessibility' ); ?>
									</option>
									<option value="non_conforme" <?php selected( $s['declaration_status'] ?? 'parzialmente', 'non_conforme' ); ?>>
										<?php esc_html_e( 'Non conforme', 'mb-accessibility' ); ?>
									</option>
									<option value="onere"        <?php selected( $s['declaration_status'] ?? 'parzialmente', 'onere' ); ?>>
										<?php esc_html_e( 'Parzialmente conforme – onere sproporzionato', 'mb-accessibility' ); ?>
									</option>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Metodo di valutazione', 'mb-accessibility' ); ?></th>
							<td>
								<select name="mba_settings[declaration_eval_method]">
									<option value="autovalutazione" <?php selected( $s['declaration_eval_method'] ?? 'autovalutazione', 'autovalutazione' ); ?>>
										<?php esc_html_e( 'Autovalutazione tramite Google Lighthouse', 'mb-accessibility' ); ?>
									</option>
									<option value="terza_parte" <?php selected( $s['declaration_eval_method'] ?? 'autovalutazione', 'terza_parte' ); ?>>
										<?php esc_html_e( 'Valutazione effettuata da terza parte', 'mb-accessibility' ); ?>
									</option>
									<option value="metodo_formale" <?php selected( $s['declaration_eval_method'] ?? 'autovalutazione', 'metodo_formale' ); ?>>
										<?php esc_html_e( 'Uso di un metodo di valutazione formale', 'mb-accessibility' ); ?>
									</option>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Data della dichiarazione', 'mb-accessibility' ); ?></th>
							<td>
								<input type="date"
								       name="mba_settings[declaration_date]"
								       value="<?php echo esc_attr( $s['declaration_date'] ?? '' ); ?>">
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Data di revisione', 'mb-accessibility' ); ?></th>
							<td>
								<input type="date"
								       name="mba_settings[declaration_review_date]"
								       value="<?php echo esc_attr( $s['declaration_review_date'] ?? '' ); ?>">
								<p class="description">
									<?php esc_html_e( 'La dichiarazione deve essere riesaminata almeno ogni 12 mesi.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
					</table>

					<!-- ===== PER-LANGUAGE FIELDS ===== -->
					<?php if ( $wpml_enabled ) : ?>
					<h2 class="mba-section-heading">
						<?php
						printf(
							/* translators: %s = language code e.g. IT, EN */
							esc_html__( 'Contenuto in %s', 'mb-accessibility' ),
							esc_html( strtoupper( $current_admin_lang ) )
						);
						?>
					</h2>
					<table class="form-table" role="presentation">
						<tr id="mba-issues-row">
							<th scope="row"><?php esc_html_e( 'Criteri non rispettati', 'mb-accessibility' ); ?></th>
							<td>
								<textarea name="mba_settings[declaration_lang_issues]"
								          rows="6"
								          class="large-text"
								          placeholder="<?php esc_attr_e( 'Un criterio per riga, es.:&#10;1.1.1 Contenuti non testuali – le immagini decorative non hanno alt vuoto&#10;2.4.4 Scopo del collegamento – alcuni link non sono descrittivi', 'mb-accessibility' ); ?>"><?php echo esc_textarea( $lang_data['issues'] ?? '' ); ?></textarea>
								<p class="description">
									<?php esc_html_e( 'Un criterio WCAG per riga. Verrà visualizzato come elenco nella dichiarazione.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
						<tr id="mba-burden-row" style="display:none;">
							<th scope="row"><?php esc_html_e( 'Motivazione onere sproporzionato', 'mb-accessibility' ); ?></th>
							<td>
								<textarea name="mba_settings[declaration_lang_burden]"
								          rows="4"
								          class="large-text"
								          placeholder="<?php esc_attr_e( 'Descrivi perché il requisito costituisce un onere sproporzionato...', 'mb-accessibility' ); ?>"><?php echo esc_textarea( $lang_data['burden_text'] ?? '' ); ?></textarea>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'URL pagina contatti', 'mb-accessibility' ); ?></th>
							<td>
								<input type="url"
								       name="mba_settings[declaration_lang_contact]"
								       value="<?php echo esc_attr( $lang_data['contact_url'] ?? '' ); ?>"
								       class="regular-text"
								       placeholder="https://esempio.it/contatti">
								<p class="description">
									<?php esc_html_e( 'Pagina contatti nella lingua corrente.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
					</table>

					<?php else : ?>
					<!-- Single-language: flat fields (backward compat) -->
					<table class="form-table" role="presentation">
						<tr id="mba-issues-row">
							<th scope="row"><?php esc_html_e( 'Criteri non rispettati', 'mb-accessibility' ); ?></th>
							<td>
								<textarea name="mba_settings[declaration_issues]"
								          rows="6"
								          class="large-text"
								          placeholder="<?php esc_attr_e( 'Un criterio per riga, es.:&#10;1.1.1 Contenuti non testuali – le immagini decorative non hanno alt vuoto&#10;2.4.4 Scopo del collegamento – alcuni link non sono descrittivi', 'mb-accessibility' ); ?>"><?php echo esc_textarea( $s['declaration_issues'] ?? '' ); ?></textarea>
								<p class="description">
									<?php esc_html_e( 'Inserisci un criterio WCAG non rispettato per riga. Verrà visualizzato come elenco nella dichiarazione.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
						<tr id="mba-burden-row" style="display:none;">
							<th scope="row"><?php esc_html_e( 'Motivazione onere sproporzionato', 'mb-accessibility' ); ?></th>
							<td>
								<textarea name="mba_settings[declaration_burden_text]"
								          rows="4"
								          class="large-text"
								          placeholder="<?php esc_attr_e( 'Descrivi perché il requisito costituisce un onere sproporzionato...', 'mb-accessibility' ); ?>"><?php echo esc_textarea( $s['declaration_burden_text'] ?? '' ); ?></textarea>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'URL pagina contatti', 'mb-accessibility' ); ?></th>
							<td>
								<input type="url"
								       name="mba_settings[declaration_contact_url]"
								       value="<?php echo esc_attr( $s['declaration_contact_url'] ?? '' ); ?>"
								       class="regular-text"
								       placeholder="https://esempio.it/contatti">
								<p class="description">
									<?php esc_html_e( 'Pagina dove gli utenti possono segnalare problemi di accessibilità o richiedere contenuti alternativi.', 'mb-accessibility' ); ?>
								</p>
							</td>
						</tr>
					</table>
					<!-- Hidden: preserve page ID across saves -->
					<input type="hidden" name="mba_settings[declaration_page_id]"
					       value="<?php echo esc_attr( $s['declaration_page_id'] ?? 0 ); ?>">
					<?php endif; ?>

					<?php submit_button( __( 'Salva dati dichiarazione', 'mb-accessibility' ), 'primary', 'mba_save_declaration', true ); ?>

				</form>

				<!-- ===== CREATE / UPDATE WP PAGE ===== -->
				<hr style="margin:24px 0;">
				<h3 style="margin-top:0;"><?php esc_html_e( 'Pagina WordPress', 'mb-accessibility' ); ?></h3>
				<?php
				if ( $wpml_enabled ) {
					$page_id    = (int) ( $lang_data['page_id'] ?? 0 );
					$lang_label = ' (' . strtoupper( $current_admin_lang ) . ')';
				} else {
					$page_id    = (int) ( $s['declaration_page_id'] ?? 0 );
					$lang_label = '';
				}
				if ( $page_id && get_post_status( $page_id ) ) :
					$page_url = get_permalink( $page_id );
				?>
				<p>
					<?php
					printf(
						wp_kses_post( __( 'Pagina esistente: <a href="%1$s" target="_blank">%1$s</a>', 'mb-accessibility' ) ),
						esc_url( $page_url )
					);
					?>
				</p>
				<?php endif; ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="mba_create_declaration_page">
					<?php wp_nonce_field( 'mba_create_declaration_page', 'mba_declaration_nonce' ); ?>
					<?php if ( $wpml_enabled ) : ?>
					<input type="hidden" name="mba_lang" value="<?php echo esc_attr( $current_admin_lang ); ?>">
					<?php endif; ?>
					<?php
					$btn_label = ( $page_id && get_post_status( $page_id ) )
						? sprintf( __( 'Aggiorna pagina dichiarazione%s', 'mb-accessibility' ), $lang_label )
						: sprintf( __( 'Crea pagina dichiarazione%s', 'mb-accessibility' ), $lang_label );
					submit_button( $btn_label, 'secondary', 'mba_do_create_page', false );
					?>
				</form>
				<p class="description">
					<?php
					if ( $wpml_enabled ) {
						esc_html_e( 'Crea una pagina WordPress con lo shortcode [mba_dichiarazione] per la lingua selezionata. Ripeti per ogni lingua attiva sul sito.', 'mb-accessibility' );
					} else {
						esc_html_e( 'Crea automaticamente una pagina WordPress a /dichiarazione-di-accessibilita/ con lo shortcode [mba_dichiarazione]. Se la pagina esiste già, la aggiorna.', 'mb-accessibility' );
					}
					?>
				</p>

			</div><!-- #mba-tab-dichiarazione -->

			<!-- ==================== TAB: AGGIORNAMENTI ==================== -->
			<!-- Outside the main form: has its own mini-form for the update check -->
			<div id="mba-tab-aggiornamenti" class="mba-tab-panel mba-tab-hidden">

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Current version', 'mb-accessibility' ); ?></th>
						<td>
							<strong><?php echo esc_html( MBA_VERSION ); ?></strong>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Check for updates', 'mb-accessibility' ); ?></th>
						<td>
							<?php
							// phpcs:ignore WordPress.Security.NonceVerification
							$update_status = isset( $_GET['mba_update'] ) ? sanitize_key( $_GET['mba_update'] ) : '';
							if ( $update_status === 'available' ) :
							?>
							<div class="notice notice-warning inline" style="margin:0 0 12px;">
								<p>
									<?php
									// phpcs:ignore WordPress.Security.NonceVerification
									$new_v = isset( $_GET['mba_new_version'] ) ? sanitize_text_field( wp_unslash( $_GET['mba_new_version'] ) ) : '';
									printf(
										/* translators: %s: new version number */
										esc_html__( 'Update available: version %s. Go to Dashboard → Updates to install it.', 'mb-accessibility' ),
										'<strong>' . esc_html( $new_v ) . '</strong>'
									);
									?>
								</p>
							</div>
							<?php elseif ( $update_status === 'latest' ) : ?>
							<div class="notice notice-success inline" style="margin:0 0 12px;">
								<p><?php esc_html_e( 'You are running the latest version.', 'mb-accessibility' ); ?></p>
							</div>
							<?php elseif ( $update_status === 'error' ) : ?>
							<div class="notice notice-error inline" style="margin:0 0 12px;">
								<p><?php esc_html_e( 'Could not connect to the update server. Please try again later.', 'mb-accessibility' ); ?></p>
							</div>
							<?php endif; ?>

							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="mba_check_updates">
								<?php wp_nonce_field( 'mba_check_updates', 'mba_updates_nonce' ); ?>
								<?php submit_button( __( 'Check for updates now', 'mb-accessibility' ), 'secondary', 'mba_do_check', false ); ?>
							</form>
							<p class="description">
								<?php esc_html_e( 'WordPress checks for updates automatically every 12 hours. Use this button to force an immediate check.', 'mb-accessibility' ); ?>
							</p>
						</td>
					</tr>
				</table>

			</div><!-- #mba-tab-aggiornamenti -->

			<p style="margin-top:8px;color:#999;font-size:12px;">
				MB Accessibility v<?php echo esc_html( MBA_VERSION ); ?> &mdash;
				<a href="https://mbdigitalinnovation.ch" target="_blank" rel="noopener">MB Digital Innovation</a>
			</p>

		</div><!-- .mba-admin-wrap -->
		<?php
	}

	// -----------------------------------------------------------------------
	// Update check handler
	// -----------------------------------------------------------------------

	public function handle_check_updates(): void {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'mb-accessibility' ) );
		}

		check_admin_referer( 'mba_check_updates', 'mba_updates_nonce' );

		global $mba_updater;
		$redirect_args = array(
			'page'           => 'mb-accessibility',
			'mba_active_tab' => 'mba-tab-aggiornamenti',
		);

		if ( ! $mba_updater ) {
			$redirect_args['mba_update'] = 'error';
			wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'options-general.php' ) ) );
			exit;
		}

		// 1. Reset PUC cache
		$mba_updater->resetUpdateState();

		// 2. Force immediate HTTP check
		$update = $mba_updater->checkForUpdates();

		// 3. Read result
		if ( $update && isset( $update->version ) && version_compare( $update->version, MBA_VERSION, '>' ) ) {
			$redirect_args['mba_update']      = 'available';
			$redirect_args['mba_new_version'] = $update->version;
		} else {
			$redirect_args['mba_update'] = 'latest';
		}

		wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'options-general.php' ) ) );
		exit;
	}
}
