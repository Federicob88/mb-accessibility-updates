<?php
/**
 * MB Accessibility – Accessibility Declaration.
 *
 * Registers the [mba_dichiarazione] shortcode and handles
 * the "Create / Update page" admin action.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MBA_Declaration {

	public function __construct() {
		add_shortcode( 'mba_dichiarazione', array( $this, 'render_shortcode' ) );
		add_action( 'admin_post_mba_create_declaration_page', array( $this, 'handle_create_page' ) );
	}

	// -----------------------------------------------------------------------
	// Shortcode
	// -----------------------------------------------------------------------

	public function render_shortcode( $atts ): string {
		$s = MBA_Plugin::get_settings();

		$org          = esc_html( $s['declaration_org_name']   ?? '' );
		$site_url     = esc_url(  $s['declaration_site_url']   ?? home_url() );
		$status       = $s['declaration_status']               ?? 'parzialmente';
		$issues       = $s['declaration_issues']               ?? '';
		$burden       = $s['declaration_burden_text']          ?? '';
		$contact_url  = esc_url(  $s['declaration_contact_url'] ?? '' );
		$eval_method  = $s['declaration_eval_method']          ?? 'autovalutazione';
		$date_decl    = esc_html( $s['declaration_date']       ?? '' );
		$date_review  = esc_html( $s['declaration_review_date'] ?? '' );

		// Status label
		$status_labels = array(
			'conforme'       => __( 'Pienamente conforme', 'mb-accessibility' ),
			'parzialmente'   => __( 'Parzialmente conforme', 'mb-accessibility' ),
			'non_conforme'   => __( 'Non conforme', 'mb-accessibility' ),
			'onere'          => __( 'Parzialmente conforme – con onere sproporzionato', 'mb-accessibility' ),
		);
		$status_label = $status_labels[ $status ] ?? $status_labels['parzialmente'];

		// Evaluation method label
		$eval_labels = array(
			'autovalutazione'  => __( 'Autovalutazione', 'mb-accessibility' ),
			'terza_parte'      => __( 'Valutazione effettuata da terza parte', 'mb-accessibility' ),
			'metodo_formale'   => __( 'Uso di un metodo di valutazione formale', 'mb-accessibility' ),
		);
		$eval_label = $eval_labels[ $eval_method ] ?? $eval_labels['autovalutazione'];

		// Build issues list
		$issues_html = '';
		if ( in_array( $status, array( 'parzialmente', 'non_conforme', 'onere' ), true ) && ! empty( $issues ) ) {
			$lines = array_filter( array_map( 'trim', explode( "\n", $issues ) ) );
			if ( $lines ) {
				$items = '';
				foreach ( $lines as $line ) {
					$items .= '<li>' . esc_html( $line ) . '</li>';
				}
				$issues_html = '<ul>' . $items . '</ul>';
			}
		}

		ob_start();
		?>
		<div class="mba-declaration">

			<h2><?php esc_html_e( 'Dichiarazione di accessibilità', 'mb-accessibility' ); ?></h2>

			<?php if ( $org ) : ?>
			<p>
				<?php
				printf(
					/* translators: %1$s = organisation name, %2$s = site URL */
					wp_kses_post( __( '<strong>%1$s</strong> si impegna a rendere il proprio sito web <a href="%2$s">%2$s</a> accessibile, conformemente al D.Lgs. 10 agosto 2018, n. 106, che ha recepito la Direttiva (UE) 2016/2102 del Parlamento europeo e del Consiglio.', 'mb-accessibility' ) ),
					esc_html( $s['declaration_org_name'] ),
					$site_url
				);
				?>
			</p>
			<?php endif; ?>

			<h3><?php esc_html_e( 'Stato di conformità', 'mb-accessibility' ); ?></h3>
			<p>
				<?php
				printf(
					/* translators: %s = conformity status label */
					esc_html__( 'Questo sito web è %s alle Linee guida per l\'accessibilità dei contenuti Web (WCAG) 2.1, livello AA.', 'mb-accessibility' ),
					'<strong>' . esc_html( $status_label ) . '</strong>'
				);
				?>
			</p>

			<?php if ( $issues_html ) : ?>
			<h3><?php esc_html_e( 'Contenuti non accessibili', 'mb-accessibility' ); ?></h3>
			<p><?php esc_html_e( 'I seguenti contenuti non sono accessibili per le ragioni indicate:', 'mb-accessibility' ); ?></p>
			<?php echo wp_kses_post( $issues_html ); ?>
			<?php endif; ?>

			<?php if ( in_array( $status, array( 'onere' ), true ) && ! empty( $burden ) ) : ?>
			<h3><?php esc_html_e( 'Onere sproporzionato', 'mb-accessibility' ); ?></h3>
			<p><?php echo esc_html( $burden ); ?></p>
			<?php endif; ?>

			<h3><?php esc_html_e( 'Alternative accessibili', 'mb-accessibility' ); ?></h3>
			<p>
				<?php
				if ( $contact_url ) {
					printf(
						/* translators: %s = contact URL */
						wp_kses_post( __( 'Per segnalare problemi di accessibilità o richiedere contenuti in formato alternativo, <a href="%s">contattaci tramite questa pagina</a>.', 'mb-accessibility' ) ),
						$contact_url
					);
				} else {
					esc_html_e( 'Per segnalare problemi di accessibilità o richiedere contenuti in formato alternativo, contattare il responsabile del sito.', 'mb-accessibility' );
				}
				?>
			</p>

			<h3><?php esc_html_e( 'Procedura di attuazione', 'mb-accessibility' ); ?></h3>
			<p>
				<?php esc_html_e( 'In caso di risposta insoddisfacente o assenza di risposta entro 30 giorni, è possibile contattare il Difensore Civico Digitale tramite il sito dell\'Agenzia per l\'Italia Digitale (AgID).', 'mb-accessibility' ); ?>
			</p>

			<h3><?php esc_html_e( 'Informazioni sulla dichiarazione di accessibilità', 'mb-accessibility' ); ?></h3>
			<ul>
				<li>
					<strong><?php esc_html_e( 'Metodo di valutazione:', 'mb-accessibility' ); ?></strong>
					<?php echo esc_html( $eval_label ); ?>
				</li>
				<?php if ( $date_decl ) : ?>
				<li>
					<strong><?php esc_html_e( 'Data della dichiarazione:', 'mb-accessibility' ); ?></strong>
					<?php echo esc_html( $date_decl ); ?>
				</li>
				<?php endif; ?>
				<?php if ( $date_review ) : ?>
				<li>
					<strong><?php esc_html_e( 'Data di revisione:', 'mb-accessibility' ); ?></strong>
					<?php echo esc_html( $date_review ); ?>
				</li>
				<?php endif; ?>
			</ul>

		</div><!-- .mba-declaration -->
		<?php
		return ob_get_clean();
	}

	// -----------------------------------------------------------------------
	// Admin action – create / update WP page
	// -----------------------------------------------------------------------

	public function handle_create_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Non hai i permessi necessari per eseguire questa azione.', 'mb-accessibility' ) );
		}

		check_admin_referer( 'mba_create_declaration_page', 'mba_declaration_nonce' );

		$s       = MBA_Plugin::get_settings();
		$page_id = ! empty( $s['declaration_page_id'] ) ? (int) $s['declaration_page_id'] : 0;

		$page_data = array(
			'post_title'   => __( 'Dichiarazione di accessibilità', 'mb-accessibility' ),
			'post_content' => '[mba_dichiarazione]',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_name'    => 'dichiarazione-di-accessibilita',
		);

		// Check if page still exists
		if ( $page_id && get_post_status( $page_id ) ) {
			$page_data['ID'] = $page_id;
			$result = wp_update_post( $page_data, true );
		} else {
			$result = wp_insert_post( $page_data, true );
		}

		$redirect_args = array(
			'page'           => 'mb-accessibility',
			'mba_active_tab' => 'mba-tab-dichiarazione',
		);

		if ( is_wp_error( $result ) ) {
			$redirect_args['mba_decl'] = 'error';
		} else {
			// Save the page ID for future updates
			$saved = get_option( 'mba_settings', array() );
			if ( ! is_array( $saved ) ) {
				$saved = array();
			}
			$saved['declaration_page_id'] = $result;
			update_option( 'mba_settings', $saved );

			$redirect_args['mba_decl']    = 'ok';
			$redirect_args['mba_decl_url'] = urlencode( get_permalink( $result ) );
		}

		wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'options-general.php' ) ) );
		exit;
	}
}
