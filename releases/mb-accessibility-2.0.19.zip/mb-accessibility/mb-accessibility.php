<?php
/**
 * Plugin Name: MB Accessibility
 * Plugin URI:  https://mbdigitalinnovation.ch
 * Description: Widget di accessibilità per WordPress con screen reader integrato, modalità di contrasto, regolazione testo, pausa animazioni e molto altro. Sviluppato da MB Digital Innovation.
 * Version:     2.0.19
 * Author:      MB Digital Innovation
 * Author URI:  https://mbdigitalinnovation.ch
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: mb-accessibility
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ---------------------------------------------------------------------------
// Plugin constants
// ---------------------------------------------------------------------------
define( 'MBA_VERSION',  '2.0.19' );
define( 'MBA_FILE',     __FILE__ );
define( 'MBA_PATH',     plugin_dir_path( __FILE__ ) );
define( 'MBA_URL',      plugin_dir_url( __FILE__ ) );

// ---------------------------------------------------------------------------
// Auto-updater (Plugin Update Checker – reads manifest from public repo)
// ---------------------------------------------------------------------------
require_once MBA_PATH . 'includes/lib/plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

/**
 * Update channel:
 *   stable (default) → update.json       — tutti i siti clienti
 *   beta             → update-dev.json   — solo siti con MBA_UPDATE_CHANNEL = 'beta' in wp-config.php
 */
$mba_update_channel  = ( defined( 'MBA_UPDATE_CHANNEL' ) && MBA_UPDATE_CHANNEL === 'beta' ) ? 'beta' : 'stable';
$mba_update_manifest = ( $mba_update_channel === 'beta' )
	? 'https://raw.githubusercontent.com/Federicob88/mb-accessibility-updates/main/update-dev.json'
	: 'https://raw.githubusercontent.com/Federicob88/mb-accessibility-updates/main/update.json';

// Store as global so the admin "Check now" button can reset PUC's state directly.
global $mba_updater;
$mba_updater = PucFactory::buildUpdateChecker(
	$mba_update_manifest,
	__FILE__,
	'mb-accessibility'
);

// ---------------------------------------------------------------------------
// Autoload classes
// ---------------------------------------------------------------------------
require_once MBA_PATH . 'includes/class-plugin.php';
require_once MBA_PATH . 'includes/class-admin.php';
require_once MBA_PATH . 'includes/class-frontend.php';

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------
add_action( 'plugins_loaded', array( 'MBA_Plugin', 'get_instance' ) );
